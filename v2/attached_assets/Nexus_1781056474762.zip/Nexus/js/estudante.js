/* ============================================
   NEXUS — Estudante Portal Scripts
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {

  // Safe localStorage helper
  function getLocalStorageItem(key, defaultValue) {
    try {
      const val = localStorage.getItem(key);
      return val ? JSON.parse(val) : defaultValue;
    } catch (e) {
      console.error(`Error parsing localStorage key "${key}":`, e);
      return defaultValue;
    }
  }

  // Premium Toast Notification helper
  function showToast(message, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let iconSvg = '';
    if (type === 'success') {
      iconSvg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
          <polyline points="22 4 12 14.01 9 11.01"></polyline>
        </svg>
      `;
    } else if (type === 'danger') {
      iconSvg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="12" y1="8" x2="12" y2="12"></line>
          <line x1="12" y1="16" x2="12.01" y2="16"></line>
        </svg>
      `;
    } else if (type === 'warning') {
      iconSvg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
          <line x1="12" y1="9" x2="12" y2="13"></line>
          <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
      `;
    } else {
      iconSvg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="12" y1="16" x2="12" y2="12"></line>
          <line x1="12" y1="8" x2="12.01" y2="8"></line>
        </svg>
      `;
    }

    toast.innerHTML = `
      ${iconSvg}
      <span style="font-family: var(--font-family-title);">${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('hide');
      toast.addEventListener('animationend', () => {
        toast.remove();
      });
    }, 4000);
  }

  let selectedPdfFile = null;
  let selectedPdfData = null;

  // Load dynamic user info from localStorage
  const loggedName = localStorage.getItem('nexus_user_name');
  const loggedMatricula = localStorage.getItem('nexus_user_matricula');
  
  if (loggedName) {
    const userNameEl = document.querySelector('.user-info .user-name');
    const userAvatarEl = document.querySelector('.user-info .user-avatar');
    if (userNameEl) userNameEl.textContent = loggedName;
    if (userAvatarEl) {
      const parts = loggedName.trim().split(/\s+/);
      const initials = parts.length >= 2 ? (parts[0][0] + parts[parts.length - 1][0]).toUpperCase() : parts[0][0].toUpperCase();
      userAvatarEl.textContent = initials;
    }
  }
  if (loggedMatricula) {
    const userMetaEl = document.querySelector('.user-info .user-meta');
    if (userMetaEl) userMetaEl.textContent = `${loggedMatricula} · UFLA`;
  }

  /* ------------------------------------------------
     1. Sidebar Navigation — Section Switching
     ------------------------------------------------ */
  const navItems = document.querySelectorAll('.sidebar-nav .nav-item[data-section]');
  const sections = document.querySelectorAll('.section[id]');

  function activateSection(sectionId) {
    // Hide all sections
    sections.forEach(s => s.classList.remove('active'));
    // Deactivate all nav items
    navItems.forEach(n => n.classList.remove('active'));

    // Show target section
    const target = document.getElementById(sectionId);
    if (target) {
      target.classList.add('active');
    }

    // Mark nav item active
    navItems.forEach(n => {
      if (n.getAttribute('data-section') === sectionId) {
        n.classList.add('active');
      }
    });
  }

  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const sectionId = item.getAttribute('data-section');
      if (sectionId) {
        activateSection(sectionId);
      }
    });
  });

  // ---- Dashboard Button Links ----
  const btnNovaSubmissaoDash = document.getElementById('btn-nova-submissao-dash');
  if (btnNovaSubmissaoDash) {
    btnNovaSubmissaoDash.addEventListener('click', (e) => {
      e.preventDefault();
      activateSection('nova-submissao');
    });
  }

  const btnVerHistorico = document.getElementById('btn-ver-historico-completo');
  if (btnVerHistorico) {
    btnVerHistorico.addEventListener('click', (e) => {
      e.preventDefault();
      activateSection('historico');
    });
  }

  /* ------------------------------------------------
     2. Coauthor Add / Remove
     ------------------------------------------------ */
  const coauthorContainer = document.getElementById('coauthor-list');
  const addCoauthorBtn = document.getElementById('add-coauthor');

  if (addCoauthorBtn && coauthorContainer) {
    addCoauthorBtn.addEventListener('click', (e) => {
      e.preventDefault();
      
      const config = getLocalStorageItem('nexus_config', { maxCoautores: 5 });
      const currentRows = coauthorContainer.querySelectorAll('.coauthor-row').length;
      if (currentRows >= config.maxCoautores) {
        showToast(`Limite máximo de ${config.maxCoautores} coautores atingido pelo edital.`, 'warning');
        return;
      }

      const row = document.createElement('div');
      row.className = 'coauthor-row';
      row.innerHTML = `
        <input type="text" class="form-input" placeholder="Nome completo">
        <input type="email" class="form-input" placeholder="email@ufla.br">
        <button type="button" class="coauthor-remove" title="Remover coautor">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="3 6 5 6 21 6"/>
            <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
            <path d="M10 11v6"/>
            <path d="M14 11v6"/>
            <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
          </svg>
        </button>
      `;
      coauthorContainer.appendChild(row);

      // Attach remove handler
      row.querySelector('.coauthor-remove').addEventListener('click', () => {
        row.remove();
      });
    });

    // Handle remove on initial rows
    coauthorContainer.querySelectorAll('.coauthor-remove').forEach(btn => {
      btn.addEventListener('click', () => {
        btn.closest('.coauthor-row').remove();
      });
    });
  }

  /* ------------------------------------------------
     3. File Drag & Drop
     ------------------------------------------------ */
  const dropZone = document.getElementById('drop-zone');
  const fileInput = document.getElementById('file-input');
  const selectFileBtn = document.getElementById('select-file-btn');
  const fileSelectedEl = document.getElementById('file-selected');
  const fileNameEl = document.getElementById('file-name');

  if (dropZone && fileInput) {
    // Click to open file dialog
    dropZone.addEventListener('click', () => fileInput.click());
    if (selectFileBtn) {
      selectFileBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        fileInput.click();
      });
    }

    // Drag events
    ['dragenter', 'dragover'].forEach(event => {
      dropZone.addEventListener(event, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropZone.classList.add('drag-over');
      });
    });

    ['dragleave', 'drop'].forEach(event => {
      dropZone.addEventListener(event, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropZone.classList.remove('drag-over');
      });
    });

    dropZone.addEventListener('drop', (e) => {
      const files = e.dataTransfer.files;
      if (files.length > 0) {
        handleFile(files[0]);
      }
    });

    fileInput.addEventListener('change', () => {
      if (fileInput.files.length > 0) {
        handleFile(fileInput.files[0]);
      }
    });

    function handleFile(file) {
      if (file.type !== 'application/pdf') {
        alert('Por favor, selecione um arquivo PDF.');
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        alert('O arquivo excede o limite de 10 MB.');
        return;
      }
      if (fileSelectedEl && fileNameEl) {
        fileNameEl.textContent = file.name;
        fileSelectedEl.classList.add('visible');
        selectedPdfFile = file;

        // Read file as base64 Data URL
        const reader = new FileReader();
        reader.onload = (e) => {
          selectedPdfData = e.target.result;
        };
        reader.onerror = (err) => {
          console.error("Erro ao ler o PDF da submissão:", err);
        };
        reader.readAsDataURL(file);

        if (dropZone) {
          dropZone.style.borderColor = '';
          dropZone.style.backgroundColor = '';
        }
        checkGlobalAlertVisibility();
      }
    }
  }

  /* ------------------------------------------------
     4. Character / Word Counter — Resumo
     ------------------------------------------------ */
  const resumoTextarea = document.getElementById('resumo');
  const charCounter = document.getElementById('char-counter');
  const MAX_WORDS = 230;

  if (resumoTextarea && charCounter) {
    resumoTextarea.addEventListener('input', () => {
      const text = resumoTextarea.value.trim();
      const words = text === '' ? 0 : text.split(/\s+/).length;
      charCounter.textContent = `${words} / ${MAX_WORDS} palavras`;

      charCounter.classList.remove('warning', 'danger');
      if (words > MAX_WORDS) {
        charCounter.classList.add('danger');
      } else if (words > MAX_WORDS * 0.9) {
        charCounter.classList.add('warning');
      }
    });
  }

  /* ------------------------------------------------
     5. .tex Import Button
     ------------------------------------------------ */
  const texInput = document.getElementById('tex-input');
  const texBtn = document.getElementById('tex-select-btn');

  if (texBtn && texInput) {
    texBtn.addEventListener('click', (e) => {
      e.preventDefault();
      texInput.click();
    });

    texInput.addEventListener('change', () => {
      if (texInput.files.length > 0) {
        const file = texInput.files[0];
        const reader = new FileReader();
        reader.onload = (e) => {
          const content = e.target.result;
          
          // Parse title: \title{...}
          let title = '';
          const titleMatch = content.match(/\\title\{([\s\S]*?)\}/);
          if (titleMatch && titleMatch[1]) {
            title = titleMatch[1].trim().replace(/\r?\n/g, ' ').replace(/\s+/g, ' ');
            title = title.replace(/\\(bf|it|large|Large|huge|Huge|small|tiny)\s*/g, '');
          }

          // Parse abstract: \begin{abstract}...\end{abstract}
          let abstract = '';
          const abstractMatch = content.match(/\\begin\{abstract\}([\s\S]*?)\\end\{abstract\}/);
          if (abstractMatch && abstractMatch[1]) {
            abstract = abstractMatch[1].trim().replace(/\r?\n/g, ' ').replace(/\s+/g, ' ');
          }

          // Fill inputs
          const tituloInput = document.getElementById('titulo');
          const resumoTextarea = document.getElementById('resumo');
          
          if (tituloInput && title) {
            tituloInput.value = title;
            tituloInput.style.borderColor = 'var(--color-primary)';
          }
          if (resumoTextarea && abstract) {
            resumoTextarea.value = abstract;
            resumoTextarea.style.borderColor = 'var(--color-primary)';
            // Trigger input event to update word counter
            resumoTextarea.dispatchEvent(new Event('input'));
          }

          // Extract orientador: search for email in comment or advisor tag
          let orientador = '';
          const orientadorMatch = content.match(/orientador(?:e?s)?\s*:\s*([a-zA-Z0-9._%+-]+@ufla\.br)/i) || 
                                  content.match(/\\advisor\{([\s\S]*?)\}/) ||
                                  content.match(/([a-zA-Z0-9._%+-]+@ufla\.br)/);
          if (orientadorMatch) {
            orientador = orientadorMatch[1].trim();
            const orientadorInput = document.getElementById('orientador');
            if (orientadorInput) {
              orientadorInput.value = orientador;
              orientadorInput.style.borderColor = 'var(--color-primary)';
            }
          }

          // Extract co-authors (other @ufla.br / @estudante.ufla.br emails)
          const allEmails = content.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g) || [];
          const uflaEmails = allEmails.filter(email => email.endsWith('@ufla.br') || email.endsWith('@estudante.ufla.br'));
          const coauthorEmails = uflaEmails.filter(email => email !== orientador);
          
          if (coauthorEmails.length > 0) {
            const coauthorContainer = document.getElementById('coauthor-list');
            if (coauthorContainer) {
              coauthorContainer.innerHTML = '';
              
              coauthorEmails.forEach(email => {
                let name = '';
                const escapedEmail = email.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
                const nameRegex = new RegExp(`([^\\n\\\\{}]+)\\s*(?:\\\\email|\\\\author|\\s)*\\{?${escapedEmail}\\}?`, 'i');
                const nameMatch = content.match(nameRegex);
                if (nameMatch && nameMatch[1]) {
                  name = nameMatch[1].trim().replace(/\\and/g, '').replace(/,/g, '').replace(/[{}\[\]]/g, '').trim();
                }
                
                const row = document.createElement('div');
                row.className = 'coauthor-row';
                row.innerHTML = `
                  <input type="text" class="form-input" placeholder="Nome completo" value="${name}">
                  <input type="email" class="form-input" placeholder="email@ufla.br" value="${email}">
                  <button type="button" class="coauthor-remove" title="Remover coautor">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <polyline points="3 6 5 6 21 6"/>
                      <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
                      <path d="M10 11v6"/>
                      <path d="M14 11v6"/>
                      <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
                    </svg>
                  </button>
                `;
                coauthorContainer.appendChild(row);
                row.querySelector('.coauthor-remove').addEventListener('click', () => {
                  row.remove();
                });
              });
            }
          }

          // Parse category (PIBIC, PIBITI, etc.)
          const lowerContent = content.toLowerCase();
          let category = '';
          if (lowerContent.includes('pibic')) {
            category = 'pibic';
          } else if (lowerContent.includes('pibiti')) {
            category = 'pibiti';
          } else if (lowerContent.includes('bic-junior') || lowerContent.includes('bic jr') || lowerContent.includes('bicjunior')) {
            category = 'bic-junior';
          } else if (lowerContent.includes('pivic')) {
            category = 'pivic';
          }
          
          if (category) {
            const categoriaSelect = document.getElementById('categoria');
            if (categoriaSelect) {
              categoriaSelect.value = category;
              categoriaSelect.style.borderColor = 'var(--color-primary)';
            }
          }

          alert(`Arquivo "${file.name}" importado com sucesso!\n\nOs campos foram preenchidos de forma automática.`);
        };
        reader.readAsText(file);
      }
    });
  }



  /* ------------------------------------------------
     7. Form Submit / Draft & Submissions Data Logic
     ------------------------------------------------ */
  const submitBtn = document.getElementById('submit-btn');
  const draftBtn = document.getElementById('draft-btn');
  const validationAlert = document.getElementById('validation-error-alert');

  // Load draft if it exists
  const draftStr = localStorage.getItem('nexus_student_draft');
  if (draftStr) {
    try {
      const draft = JSON.parse(draftStr);
      if (draft.titulo) document.getElementById('titulo').value = draft.titulo;
      if (draft.resumo) {
        const resumoTextarea = document.getElementById('resumo');
        resumoTextarea.value = draft.resumo;
        resumoTextarea.dispatchEvent(new Event('input'));
      }
      if (draft.categoria) document.getElementById('categoria').value = draft.categoria;
      if (draft.orientador) document.getElementById('orientador').value = draft.orientador;
      if (draft.coautores && draft.coautores.length > 0) {
        const coauthorContainer = document.getElementById('coauthor-list');
        if (coauthorContainer) {
          coauthorContainer.innerHTML = '';
          draft.coautores.forEach(c => {
            const row = document.createElement('div');
            row.className = 'coauthor-row';
            row.innerHTML = `
              <input type="text" class="form-input" placeholder="Nome completo" value="${c.nome}">
              <input type="email" class="form-input" placeholder="email@ufla.br" value="${c.email}">
              <button type="button" class="coauthor-remove" title="Remover coautor">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <polyline points="3 6 5 6 21 6"/>
                  <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
                  <path d="M10 11v6"/>
                  <path d="M14 11v6"/>
                  <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
                </svg>
              </button>
            `;
            coauthorContainer.appendChild(row);
            row.querySelector('.coauthor-remove').addEventListener('click', () => row.remove());
          });
        }
      }
    } catch(e) {
      console.error('Error parsing draft:', e);
    }
  }

  // Helper to remove error status on input/change
  const inputsToTrack = ['titulo', 'resumo', 'categoria', 'orientador'];
  inputsToTrack.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      const eventName = el.tagName === 'SELECT' ? 'change' : 'input';
      el.addEventListener(eventName, () => {
        el.classList.remove('is-error');
        el.style.borderColor = '';
        checkGlobalAlertVisibility();
      });
    }
  });

  function checkGlobalAlertVisibility() {
    let hasErrors = false;
    inputsToTrack.forEach(id => {
      const el = document.getElementById(id);
      if (el && el.classList.contains('is-error')) {
        hasErrors = true;
      }
    });
    if (!selectedPdfFile && dropZone && dropZone.style.borderColor === 'var(--color-danger)') {
      hasErrors = true;
    }
    if (!hasErrors && validationAlert) {
      validationAlert.style.display = 'none';
    }
  }

  // Render submissions on page load
  renderSubmissions();
  renderDashboard();

  function applyAdminConfig() {
    const config = getLocalStorageItem('nexus_config', {
      abertura: '2026-01-04',
      encerramento: '2026-05-31',
      maxCoautores: 5,
      edital: ''
    });

    const pageDesc = document.querySelector('#nova-submissao .page-description');
    if (pageDesc && config.edital) {
      pageDesc.textContent = config.edital;
    }

    const now = new Date();
    const aberturaDate = new Date(config.abertura + 'T00:00:00');
    const encerramentoDate = new Date(config.encerramento + 'T23:59:59');

    // Update Template Links
    if (config.links) {
      const btnWord = document.querySelector('button[data-filename="template_artigo_word.docx"]');
      if (btnWord && config.links.templateWord) {
        btnWord.classList.remove('btn-baixar-doc');
        btnWord.onclick = (e) => { e.preventDefault(); window.open(config.links.templateWord, '_blank'); };
      }
      
      const btnLatex = document.querySelector('button[data-filename="template_artigo_latex.tex"]');
      if (btnLatex && config.links.templateLatex) {
        btnLatex.classList.remove('btn-baixar-doc');
        btnLatex.onclick = (e) => { e.preventDefault(); window.open(config.links.templateLatex, '_blank'); };
      }
    }

    const oldAlert = document.getElementById('dynamic-period-alert');
    if (oldAlert) oldAlert.remove();

    if (now < aberturaDate || now > encerramentoDate) {
      const headerTitle = document.querySelector('#nova-submissao .page-header');
      if (headerTitle) {
         const alertHTML = `<div id="dynamic-period-alert" class="alert alert-danger" style="margin-top: 16px;"><strong>Período Fechado:</strong> O período de submissões não está aberto. Abertura: ${config.abertura} | Encerramento: ${config.encerramento}</div>`;
         headerTitle.insertAdjacentHTML('afterend', alertHTML);
      }
      if (submitBtn) {
         submitBtn.disabled = true;
         submitBtn.style.opacity = '0.5';
         submitBtn.style.pointerEvents = 'none';
         submitBtn.textContent = 'FORA DO PRAZO';
      }
      if (addCoauthorBtn) addCoauthorBtn.style.display = 'none';
    } else {
      if (submitBtn) {
         submitBtn.disabled = false;
         submitBtn.style.opacity = '1';
         submitBtn.style.pointerEvents = 'auto';
         submitBtn.innerHTML = `
           <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
             <line x1="22" y1="2" x2="11" y2="13"></line>
             <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
           </svg>
           SUBMETER TRABALHO
         `;
      }
      if (addCoauthorBtn) addCoauthorBtn.style.display = 'flex';
    }
  }

  applyAdminConfig();
  window.addEventListener('storage', (e) => {
    if (e.key === 'nexus_config') {
      applyAdminConfig();
      renderDashboard(); // Re-render dashboard instantly to update "Próximo Prazo"
    }
  });

  if (submitBtn) {
    submitBtn.addEventListener('click', (e) => {
      e.preventDefault();
      
      let isValid = true;
      
      // 1. Title validation
      const tituloInput = document.getElementById('titulo');
      if (tituloInput) {
        if (!tituloInput.value.trim()) {
          tituloInput.classList.add('is-error');
          tituloInput.style.borderColor = 'var(--color-danger)';
          isValid = false;
        } else {
          tituloInput.classList.remove('is-error');
          tituloInput.style.borderColor = '';
        }
      }

      // 2. Abstract validation
      const resumoTextarea = document.getElementById('resumo');
      if (resumoTextarea) {
        const text = resumoTextarea.value.trim();
        const words = text === '' ? 0 : text.split(/\s+/).length;
        if (!text || words > 230) {
          resumoTextarea.classList.add('is-error');
          resumoTextarea.style.borderColor = 'var(--color-danger)';
          isValid = false;
        } else {
          resumoTextarea.classList.remove('is-error');
          resumoTextarea.style.borderColor = '';
        }
      }

      // 3. Category validation
      const categoriaSelect = document.getElementById('categoria');
      if (categoriaSelect) {
        if (categoriaSelect.value === '') {
          categoriaSelect.classList.add('is-error');
          categoriaSelect.style.borderColor = 'var(--color-danger)';
          isValid = false;
        } else {
          categoriaSelect.classList.remove('is-error');
          categoriaSelect.style.borderColor = '';
        }
      }

      // 4. Advisor Email validation
      const orientadorInput = document.getElementById('orientador');
      if (orientadorInput) {
        const email = orientadorInput.value.trim();
        const allowedDomains = ['ufla.br', 'estudante.ufla.br'];
        const domain = email.includes('@') ? email.split('@')[1]?.toLowerCase().trim() : '';
        const isInstitutional = allowedDomains.includes(domain);
        
        if (!email || !isInstitutional) {
          orientadorInput.classList.add('is-error');
          orientadorInput.style.borderColor = 'var(--color-danger)';
          isValid = false;
        } else {
          orientadorInput.classList.remove('is-error');
          orientadorInput.style.borderColor = '';
        }
      }

      // 5. Coauthors validation
      const coauthorRows = document.querySelectorAll('.coauthor-row');
      const coautores = [];
      let coauthorsValid = true;
      coauthorRows.forEach(row => {
        const inputs = row.querySelectorAll('input');
        const nome = inputs[0]?.value.trim();
        const email = inputs[1]?.value.trim();
        if (nome || email) {
          if (!nome || !email || !email.includes('@')) {
            inputs[0].classList.add('is-error');
            inputs[1].classList.add('is-error');
            coauthorsValid = false;
          } else {
            inputs[0].classList.remove('is-error');
            inputs[1].classList.remove('is-error');
            coautores.push({ nome, email });
          }
        }
      });
      if (!coauthorsValid) {
        isValid = false;
      }

      // 6. File drop zone validation
      if (dropZone) {
        if (!selectedPdfFile) {
          dropZone.style.borderColor = 'var(--color-danger)';
          dropZone.style.backgroundColor = 'var(--red-50)';
          isValid = false;
        } else {
          dropZone.style.borderColor = '';
          dropZone.style.backgroundColor = '';
        }
      }

      // Handle validation result
      if (!isValid) {
        if (validationAlert) {
          validationAlert.style.display = 'flex';
          validationAlert.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        return;
      }

      // If valid, hide alert and submit
      if (validationAlert) {
        validationAlert.style.display = 'none';
      }
      
      // Save submission data
      const protocolNum = 'NEXUS-2026-' + Math.floor(1000 + Math.random() * 9000);
      const newSub = {
        id: protocolNum,
        titulo: tituloInput.value.trim(),
        resumo: resumoTextarea.value.trim(),
        categoria: categoriaSelect.value,
        orientador: orientadorInput.value.trim(),
        coautores: coautores,
        autorNome: loggedName || 'Maria Silva',
        autorMatricula: loggedMatricula || '202310123',
        autorEmail: localStorage.getItem('nexus_user_email') || 'maria.silva@estudante.ufla.br',
        status: 'Recebido',
        dataSubmissao: new Date().toISOString(),
        ultimaAtualizacao: new Date().toISOString(),
        rodadas: [
          {
            rodada: 1,
            dataEnvio: new Date().toISOString(),
            pdfName: selectedPdfFile ? selectedPdfFile.name : (protocolNum + '_artigo.pdf'),
            pdfData: selectedPdfData,
            status: 'Recebido',
            parecer: '',
            comentarios: ''
          }
        ],
        statusHistory: [
          {
            statusAnterior: '-',
            statusNovo: 'Recebido',
            dataHora: new Date().toISOString(),
            justificativa: 'Submissão inicial realizada com sucesso.'
          }
        ]
      };

      const submissoes = getLocalStorageItem('nexus_submissoes', []);
      submissoes.push(newSub);
      localStorage.setItem('nexus_submissoes', JSON.stringify(submissoes));

      // Notification
      const notificacoes = getLocalStorageItem('nexus_notificacoes', []);
      notificacoes.unshift({
        tipo: 'SUBMISSÃO',
        title: 'Nova submissão realizada',
        desc: `O trabalho "${newSub.titulo}" foi submetido na categoria ${newSub.categoria.toUpperCase()}. Protocolo: ${newSub.id}`,
        time: 'agora',
        unread: true,
        timestamp: new Date().toISOString()
      });
      localStorage.setItem('nexus_notificacoes', JSON.stringify(notificacoes));

      // Clean draft
      localStorage.removeItem('nexus_student_draft');

      showToast(`Submissão enviada com sucesso! Protocolo: ${protocolNum}`, 'success');

      // Reset form fields
      if (tituloInput) tituloInput.value = '';
      if (resumoTextarea) {
        resumoTextarea.value = '';
        resumoTextarea.dispatchEvent(new Event('input'));
      }
      if (categoriaSelect) categoriaSelect.value = '';
      if (orientadorInput) orientadorInput.value = '';
      
      const coauthorContainer = document.getElementById('coauthor-list');
      if (coauthorContainer) {
        coauthorContainer.innerHTML = `
          <div class="coauthor-row">
            <input type="text" class="form-input" placeholder="Nome completo">
            <input type="email" class="form-input" placeholder="email@ufla.br">
            <button type="button" class="coauthor-remove" title="Remover coautor">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="3 6 5 6 21 6"/>
                <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
                <path d="M10 11v6"/>
                <path d="M14 11v6"/>
                <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
              </svg>
            </button>
          </div>
        `;
        coauthorContainer.querySelector('.coauthor-remove').addEventListener('click', () => {
          coauthorContainer.querySelector('.coauthor-row').remove();
        });
      }

      selectedPdfFile = null;
      selectedPdfData = null;
      if (fileSelectedEl) fileSelectedEl.classList.remove('visible');
      if (fileNameEl) fileNameEl.textContent = '';
      if (fileInput) fileInput.value = '';

      renderSubmissions();
      renderDashboard();
      activateSection('historico');
    });
  }

  if (draftBtn) {
    draftBtn.addEventListener('click', (e) => {
      e.preventDefault();
      
      const coauthorRows = document.querySelectorAll('.coauthor-row');
      const coautores = [];
      coauthorRows.forEach(row => {
        const inputs = row.querySelectorAll('input');
        const nome = inputs[0]?.value.trim();
        const email = inputs[1]?.value.trim();
        if (nome || email) {
          coautores.push({ nome, email });
        }
      });

      const draft = {
        titulo: document.getElementById('titulo')?.value || '',
        resumo: document.getElementById('resumo')?.value || '',
        categoria: document.getElementById('categoria')?.value || '',
        orientador: document.getElementById('orientador')?.value || '',
        coautores: coautores
      };

      localStorage.setItem('nexus_student_draft', JSON.stringify(draft));
      showToast('Rascunho do formulário salvo com sucesso!', 'success');
    });
  }

  // ---- Render Dashboard ----
  function renderDashboard() {
    const matricula = localStorage.getItem('nexus_user_matricula') || '202310123';
    const submissoes = getLocalStorageItem('nexus_submissoes', []);
    const mySubs = submissoes.filter(s => s.autorMatricula === matricula);

    // Calculate metrics
    const ativas = mySubs.filter(s => s.status !== 'Aprovado' && s.status !== 'Reprovado' && s.status !== 'Desclassificado');
    const emAvaliacao = mySubs.filter(s => s.status === 'Em Avaliação');
    const aprovadas = mySubs.filter(s => s.status === 'Aprovado');
    
    // Nearest deadline based on Admin config (Encerramento)
    const config = getLocalStorageItem('nexus_config', { encerramento: '2026-05-31' });
    let minDays = Infinity;
    
    if (config.encerramento) {
      const encerramentoDate = new Date(config.encerramento + 'T23:59:59');
      const diffTime = encerramentoDate - new Date();
      minDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    const dashAtivas = document.getElementById('dash-count-ativas');
    const dashAval = document.getElementById('dash-count-avaliacao');
    const dashAprov = document.getElementById('dash-count-aprovadas');
    const dashPrazo = document.getElementById('dash-proximo-prazo');

    if (dashAtivas) dashAtivas.textContent = ativas.length;
    if (dashAval) dashAval.textContent = emAvaliacao.length;
    if (dashAprov) dashAprov.textContent = aprovadas.length;
    
    if (dashPrazo) {
      if (minDays === Infinity) {
        dashPrazo.textContent = '-';
      } else if (minDays < 0) {
        dashPrazo.textContent = 'Encerrado';
        dashPrazo.style.color = 'var(--color-danger)';
      } else {
        dashPrazo.textContent = minDays + ' dias';
        dashPrazo.style.color = '';
      }
    }

    // Render Active Submissions List
    const activeList = document.getElementById('dashboard-active-submissions');
    if (activeList) {
      activeList.innerHTML = '';
      if (ativas.length === 0) {
        activeList.innerHTML = '<div style="color: var(--color-text-muted); font-size: var(--fs-sm); padding: var(--space-4) 0;">Nenhuma submissão ativa no momento.</div>';
      } else {
        // Sort by most recent
        ativas.sort((a, b) => new Date(b.ultimaAtualizacao) - new Date(a.ultimaAtualizacao));
        
        ativas.forEach(sub => {
          let statusClass = 'amber';
          if (sub.status === 'Recebido') statusClass = 'blue';
          else if (sub.status === 'Aprovado') statusClass = 'green';
          else if (sub.status === 'Reprovado' || sub.status === 'Desclassificado') statusClass = 'red';
          else if (sub.status === 'Aprovado com Correções') statusClass = 'green';
          else if (sub.status === 'Correções Necessárias') statusClass = 'amber';
          else if (sub.status === 'Em Avaliação') statusClass = 'blue';

          const dateObj = new Date(sub.ultimaAtualizacao || sub.dataSubmissao || new Date());
          
          const now = new Date();
          const diffMs = now - dateObj;
          const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
          const diffDaysDate = Math.floor(diffMs / (1000 * 60 * 60 * 24));
          
          let dateText = '';
          if (diffHrs < 24) {
            dateText = diffHrs === 0 ? 'Atualizado agora mesmo' : `Atualizado há ${diffHrs} horas`;
          } else if (diffDaysDate === 1) {
            dateText = 'Atualizado ontem';
          } else if (diffDaysDate < 7) {
            dateText = `Atualizado há ${diffDaysDate} dias`;
          } else {
            dateText = 'Atualizado há mais de uma semana';
          }

          const numCoauthors = sub.coautores ? sub.coautores.length : 0;
          const coauthorText = numCoauthors === 1 ? '1 coautor' : `${numCoauthors} coautores`;

          const cardHtml = `
            <div class="dashboard-work-card">
              <div class="dash-card-left">
                <div class="dash-card-meta-top">
                  <span class="badge badge-gray">${sub.categoria.toUpperCase()}</span>
                  <span class="dash-card-id">${sub.id}</span>
                </div>
                <div class="dash-card-title">${sub.titulo}</div>
                <div class="dash-card-meta-bottom">
                  <div title="Coautores"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg> ${coauthorText}</div>
                  <div title="Última atualização"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> ${dateText}</div>
                </div>
              </div>
              <div class="dash-card-right">
                <span class="badge badge-solid-${statusClass}">${sub.status.toUpperCase()}</span>
              </div>
            </div>
          `;
          activeList.innerHTML += cardHtml;
        });
      }
    }
  }

  // ---- Render Submissions List ----
  function renderSubmissions() {
    const matricula = localStorage.getItem('nexus_user_matricula') || '202310123';
    const submissoes = getLocalStorageItem('nexus_submissoes', []);
    const mySubs = submissoes.filter(s => s.autorMatricula === matricula);

    const emptyState = document.querySelector('#historico .empty-state');
    const listContainer = document.getElementById('submissions-list-container');
    const tableBody = document.querySelector('#submissions-table tbody');

    if (mySubs.length === 0) {
      if (emptyState) emptyState.style.display = 'flex';
      if (listContainer) listContainer.style.display = 'none';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';
    if (listContainer) listContainer.style.display = 'block';

    if (tableBody) {
      tableBody.innerHTML = '';
      mySubs.forEach(sub => {
        const row = document.createElement('tr');
        
        let statusClass = 'amber';
        if (sub.status === 'Aprovado') statusClass = 'green';
        else if (sub.status === 'Reprovado' || sub.status === 'Desclassificado') statusClass = 'red';
        else if (sub.status === 'Aprovado com Correções' || sub.status === 'Correções Necessárias') statusClass = 'blue';

        const dateObj = new Date(sub.ultimaAtualizacao || sub.dataSubmissao || new Date());
        const formattedDate = dateObj.toLocaleDateString('pt-BR') + ' ' + dateObj.toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'});

        row.innerHTML = `
          <td style="padding: var(--space-4) var(--space-5);">
            <strong style="color: var(--color-primary);">${sub.id}</strong>
            <div style="font-size: var(--fs-xs); color: var(--color-text-secondary); max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${sub.titulo}</div>
          </td>
          <td style="padding: var(--space-4) var(--space-5);"><span class="badge badge-gray">${sub.categoria.toUpperCase()}</span></td>
          <td style="padding: var(--space-4) var(--space-5);"><span class="status-dot ${statusClass}">${sub.status}</span></td>
          <td style="padding: var(--space-4) var(--space-5); font-size: var(--fs-xs); color: var(--color-text-secondary);">${formattedDate}</td>
          <td style="padding: var(--space-4) var(--space-5);">
            <button class="btn btn-outline btn-sm btn-detalhes" data-id="${sub.id}">DETALHES</button>
          </td>
        `;
        tableBody.appendChild(row);
      });

      // Details button click handler
      tableBody.querySelectorAll('.btn-detalhes').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          const subId = btn.getAttribute('data-id');
          openDetailsModal(subId);
        });
      });
    }
  }

  // ---- Modal Logic ----
  const modal = document.getElementById('sub-details-modal');
  const closeModalBtn = document.getElementById('close-modal-btn');
  const modalBtnReenviar = document.getElementById('modal-btn-reenviar');

  // Modal file upload controls
  const modalFileInput = document.getElementById('modal-file-input');
  const modalBtnSelectFile = document.getElementById('modal-btn-select-file');
  const modalFileSelectedName = document.getElementById('modal-file-selected-name');
  let modalSelectedPdfFile = null;
  let modalSelectedPdfData = null;

  if (modalBtnSelectFile && modalFileInput) {
    modalBtnSelectFile.addEventListener('click', (e) => {
      e.preventDefault();
      modalFileInput.click();
    });

    modalFileInput.addEventListener('change', () => {
      if (modalFileInput.files.length > 0) {
        const file = modalFileInput.files[0];
        if (file.type !== 'application/pdf') {
          alert('Por favor, selecione um arquivo PDF.');
          return;
        }
        if (file.size > 10 * 1024 * 1024) {
          alert('O arquivo excede o limite de 10 MB.');
          return;
        }
        modalSelectedPdfFile = file;

        if (modalFileSelectedName) {
          modalFileSelectedName.textContent = file.name;
          modalFileSelectedName.style.display = 'block';
        }
        if (modalBtnReenviar) {
          modalBtnReenviar.style.display = 'block';
        }

        const reader = new FileReader();
        reader.onload = (e) => {
          modalSelectedPdfData = e.target.result;
        };
        reader.onerror = (err) => {
          console.error("Erro ao ler o PDF no modal:", err);
        };
        reader.readAsDataURL(file);
      }
    });
  }

  function openDetailsModal(subId) {
    const submissoes = getLocalStorageItem('nexus_submissoes', []);
    const sub = submissoes.find(s => s.id === subId);
    if (!sub) return;

    document.getElementById('modal-protocol-title').textContent = sub.id;
    document.getElementById('modal-work-title').textContent = sub.titulo;
    document.getElementById('modal-category').textContent = sub.categoria.toUpperCase();
    document.getElementById('modal-advisor').textContent = sub.orientador;

    const coauthorsContainer = document.getElementById('modal-coauthors');
    if (coauthorsContainer) {
      if (sub.coautores && sub.coautores.length > 0) {
        coauthorsContainer.innerHTML = sub.coautores.map(c => `<div>${c.nome} (${c.email})</div>`).join('');
      } else {
        coauthorsContainer.textContent = 'Nenhum';
      }
    }

    const historyContainer = document.getElementById('modal-status-history');
    if (historyContainer) {
      historyContainer.innerHTML = '';
      const statusHistory = sub.statusHistory || [];
      statusHistory.forEach(h => {
        const dateObj = new Date(h.dataHora);
        const dateStr = dateObj.toLocaleDateString('pt-BR') + ' ' + dateObj.toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'});
        
        const historyRow = document.createElement('div');
        historyRow.style.display = 'flex';
        historyRow.style.flexDirection = 'column';
        historyRow.style.borderLeft = '2px solid var(--color-border)';
        historyRow.style.paddingLeft = 'var(--space-3)';
        historyRow.style.marginLeft = 'var(--space-1)';
        historyRow.style.position = 'relative';
        historyRow.style.marginBottom = 'var(--space-2)';

        historyRow.innerHTML = `
          <div style="font-size: var(--fs-xs); font-weight: var(--fw-semibold); color: var(--color-text);">${h.statusNovo}</div>
          <div style="font-size: var(--fs-xs); color: var(--color-text-secondary);">${dateStr} ${h.statusAnterior && h.statusAnterior !== '-' ? `(Anterior: ${h.statusAnterior})` : ''}</div>
          ${h.justificativa ? `<div style="font-size: var(--fs-xs); color: var(--color-text-secondary); margin-top: 2px;"><em>${h.justificativa}</em></div>` : ''}
        `;
        historyContainer.appendChild(historyRow);
      });
    }

    const commentsContainer = document.getElementById('modal-reviewer-comments-container');
    const commentsText = document.getElementById('modal-reviewer-comments');
    
    const latestRoundWithComments = [...(sub.rodadas || [])].reverse().find(r => r.comentarios);
    if (commentsContainer && commentsText) {
      if (latestRoundWithComments && latestRoundWithComments.comentarios) {
        commentsText.textContent = `[Rodada ${latestRoundWithComments.rodada}] ${latestRoundWithComments.comentarios}`;
        commentsContainer.style.display = 'block';
      } else {
        commentsContainer.style.display = 'none';
      }
    }

    const reenvioContainer = document.getElementById('modal-reenvio-container');
    if (reenvioContainer) {
      if (sub.status === 'Correções Necessárias' || sub.status === 'Aprovado com Correções') {
        reenvioContainer.style.display = 'block';
        if (modalBtnReenviar) {
          modalBtnReenviar.setAttribute('data-subid', sub.id);
          modalBtnReenviar.style.display = 'none'; // Hide until a file is selected
        }
        // Reset modal file inputs
        modalSelectedPdfFile = null;
        modalSelectedPdfData = null;
        if (modalFileInput) modalFileInput.value = '';
        if (modalFileSelectedName) {
          modalFileSelectedName.textContent = '';
          modalFileSelectedName.style.display = 'none';
        }
      } else {
        reenvioContainer.style.display = 'none';
      }
    }

    if (modal) {
      modal.style.display = 'flex';
    }
  }

  if (closeModalBtn) {
    closeModalBtn.addEventListener('click', () => {
      if (modal) modal.style.display = 'none';
    });
  }
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.style.display = 'none';
      }
    });
  }

  // Handle re-submission of corrected version
  if (modalBtnReenviar) {
    modalBtnReenviar.addEventListener('click', (e) => {
      e.preventDefault();
      const subId = modalBtnReenviar.getAttribute('data-subid');
      if (!subId) return;

      if (!modalSelectedPdfFile || !modalSelectedPdfData) {
        alert('Por favor, selecione um arquivo PDF antes de reenviar.');
        return;
      }

      const submissoes = getLocalStorageItem('nexus_submissoes', []);
      const subIndex = submissoes.findIndex(s => s.id === subId);
      if (subIndex === -1) return;

      const sub = submissoes[subIndex];

      if (confirm(`Deseja enviar a versão corrigida do arquivo "${modalSelectedPdfFile.name}" para o trabalho ${sub.id}?`)) {
        sub.rodadas = sub.rodadas || [];
        const nextRoundNum = sub.rodadas.length + 1;
        const currentStatus = sub.status;
        const newStatus = 'Em Avaliação';
        
        sub.rodadas.push({
          rodada: nextRoundNum,
          dataEnvio: new Date().toISOString(),
          pdfName: modalSelectedPdfFile.name,
          pdfData: modalSelectedPdfData,
          status: 'Recebido',
          parecer: '',
          comentarios: ''
        });

        sub.statusHistory = sub.statusHistory || [];
        sub.statusHistory.push({
          statusAnterior: currentStatus,
          statusNovo: newStatus,
          dataHora: new Date().toISOString(),
          justificativa: `Versão corrigida enviada (Rodada ${nextRoundNum}).`
        });

        sub.status = newStatus;
        sub.ultimaAtualizacao = new Date().toISOString();

        submissoes[subIndex] = sub;
        localStorage.setItem('nexus_submissoes', JSON.stringify(submissoes));

        const notificacoes = getLocalStorageItem('nexus_notificacoes', []);
        notificacoes.unshift({
          tipo: 'SUBMISSÃO',
          title: 'Versão corrigida reenviada',
          desc: `O trabalho "${sub.titulo}" recebeu reenvio (Rodada ${nextRoundNum}). Protocolo: ${sub.id}`,
          time: 'agora',
          unread: true,
          timestamp: new Date().toISOString()
        });
        localStorage.setItem('nexus_notificacoes', JSON.stringify(notificacoes));

        showToast('Versão corrigida reenviada com sucesso!', 'success');
        
        // Reset modal variables
        modalSelectedPdfFile = null;
        modalSelectedPdfData = null;
        if (modalFileInput) modalFileInput.value = '';
        if (modalFileSelectedName) {
          modalFileSelectedName.textContent = '';
          modalFileSelectedName.style.display = 'none';
        }
        modalBtnReenviar.style.display = 'none';

        if (modal) modal.style.display = 'none';
        renderSubmissions();
      renderDashboard();
      }
    });
  }

  // Cross-tab real-time sync with localStorage
  let lastSubmissoesString = localStorage.getItem('nexus_submissoes') || '[]';
  setInterval(() => {
    const currentString = localStorage.getItem('nexus_submissoes') || '[]';
    if (currentString !== lastSubmissoesString) {
      lastSubmissoesString = currentString;
      renderSubmissions();
      renderDashboard();
      if (modal && modal.style.display === 'flex') {
        const activeSubId = document.getElementById('modal-protocol-title')?.textContent;
        if (activeSubId) {
          openDetailsModal(activeSubId);
        }
      }
    }
  }, 2000);

  // ---- Empty State Go to Nova Submissão ----
  const goSubBtn = document.querySelector('.btn-go-submissao');
  if (goSubBtn) {
    goSubBtn.addEventListener('click', (e) => {
      e.preventDefault();
      activateSection('nova-submissao');
    });
  }

  // ---- Logout Confirmation ----
  const logoutLink = document.querySelector('.sidebar-footer .nav-item');
  if (logoutLink) {
    logoutLink.addEventListener('click', (e) => {
      e.preventDefault();
      if (confirm('Deseja realmente sair do Portal do Estudante?')) {
        localStorage.removeItem('nexus_user_name');
        localStorage.removeItem('nexus_user_matricula');
        localStorage.removeItem('nexus_user_email');
        localStorage.removeItem('nexus_user_perfil');
        window.location.href = 'login.html';
      }
    });
  }

  /* ---- Simulated Downloads for Prototype ---- */
  function setupSimulatedDownloads() {
    const downloadBtns = document.querySelectorAll('.btn-baixar-doc');
    downloadBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        const filename = btn.getAttribute('data-filename') || 'documento.pdf';
        
        let content = '';
        if (filename.endsWith('.tex')) {
          content = `\\documentclass{article}\n\\usepackage[utf8]{inputenc}\n\n\\title{Desenvolvimento de Algoritmos Computacionais Aplicados a Otimizacao de Sistemas de Energia}\n\\author{Carlos Souza {carlos.souza@estudante.ufla.br}}\n\\date{Maio 2026}\n\n% orientador: prof.almeida@ufla.br\n\n\\begin{document}\n\n\\maketitle\n\n\\begin{abstract}\nEste trabalho apresenta o desenvolvimento e a implementacao de novos algoritmos evolucionarios aplicados ao problema de otimizacao de despacho economico de sistemas eletricos de potencia. Atraves de simulacoes realizadas em sistemas de teste da literatura (IEEE 14 e 30 barras), constatou-se que a abordagem proposta atinge convergencia mais rapida e solucoes com custo operacional ate 3.5% menor do que tecnicas classicas de programacao linear. Os resultados obtidos indicam o potencial de aplicacao da ferramenta em centros de operacao em tempo real, contribuindo para a eficiencia e sustentabilidade energetica da rede de distribuicao.\n\\end{abstract}\n\n\\section{Introducao}\nO despacho economico e um problema classico de otimizacao PIBIC...\n\n\\end{document}`;
        } else {
          content = `NEXUS — SISTEMA DE SUBMISSÕES CIENTÍFICAS DA UFLA (CONGRESSO 2026)\n\n`;
          content += `Documento: ${filename}\n`;
          content += `------------------------------------------------------------\n\n`;
          content += `Este é um modelo de documento ou formulário oficial do Congresso NEXUS 2026.\n`;
          content += `O arquivo oficial correspondente a "${filename}" estará disponível para download direto no sistema em breve.\n\n`;
          content += `Para fins de homologação e testes do protótipo frontend, este arquivo placeholder foi gerado dinamicamente através de um Blob no navegador.\n\n`;
          content += `Nexus Corp & UFLA — 2026`;
        }
        
        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      });
    });
  }

  setupSimulatedDownloads();

});


/* ============================================
   NEXUS — Auth Pages Interactivity
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {
  initInstitutionalEmailCheck();
  initPasswordToggle();
  initCadastroForm();
  initLoginForm();
  setupSimulatedDownloads();
  
  // Auto-select profile if specified in URL
  const urlParams = new URLSearchParams(window.location.search);
  const requestedProfile = urlParams.get('perfil');
  if (requestedProfile) {
    const radio = document.querySelector(`input[name="loginPerfil"][value="${requestedProfile}"]`);
    if (radio) {
      radio.checked = true;
      radio.dispatchEvent(new Event('change'));
    }
  }
});

/* ---- Institutional Email Validation ---- */
const ALLOWED_DOMAINS = ['ufla.br', 'estudante.ufla.br'];

function isInstitutionalEmail(email) {
  if (!email || !email.includes('@')) return false;
  const domain = email.split('@')[1]?.toLowerCase().trim();
  return ALLOWED_DOMAINS.includes(domain);
}

function initInstitutionalEmailCheck() {
  const emailInputs = document.querySelectorAll('[data-validate="institutional-email"]');

  emailInputs.forEach(input => {
    const hint = input.closest('.form-group')?.querySelector('.form-hint');

    input.addEventListener('input', () => {
      const value = input.value.trim();

      if (value === '') {
        // Reset to default state
        input.classList.remove('is-error');
        if (hint) {
          hint.classList.remove('is-error');
          hint.style.display = 'none';
        }
        return;
      }

      if (value.includes('@') && !isInstitutionalEmail(value)) {
        input.classList.add('is-error');
        if (hint) {
          hint.classList.add('is-error');
          hint.style.display = 'flex';
        }
      } else {
        input.classList.remove('is-error');
        if (hint) {
          hint.classList.remove('is-error');
          hint.style.display = 'none';
        }
      }
    });

    input.addEventListener('blur', () => {
      const value = input.value.trim();
      if (value && !isInstitutionalEmail(value)) {
        input.classList.add('is-error');
        if (hint) {
          hint.classList.add('is-error');
          hint.style.display = 'flex';
        }
      }
    });
  });
}

/* ---- Password Toggle ---- */
function initPasswordToggle() {
  const toggleButtons = document.querySelectorAll('.password-toggle');

  toggleButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const wrapper = btn.closest('.password-wrapper');
      const input = wrapper?.querySelector('input');
      if (!input) return;

      const isPassword = input.type === 'password';
      input.type = isPassword ? 'text' : 'password';

      // Swap icon
      const eyeOpen = btn.querySelector('.eye-open');
      const eyeClosed = btn.querySelector('.eye-closed');
      if (eyeOpen && eyeClosed) {
        eyeOpen.style.display = isPassword ? 'none' : 'block';
        eyeClosed.style.display = isPassword ? 'block' : 'none';
      }
    });
  });
}

/* ---- Cadastro Form ---- */
function initCadastroForm() {
  const form = document.getElementById('cadastroForm');
  if (!form) return;

  // Initialize registered users in localStorage if not exists
  if (!localStorage.getItem('nexus_registered_users')) {
    localStorage.setItem('nexus_registered_users', JSON.stringify([
      { matricula: '202310123', email: 'maria.silva@estudante.ufla.br', name: 'Maria Silva' }
    ]));
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    clearErrors(form);

    const nome = form.querySelector('#nome');
    const matricula = form.querySelector('#matricula');
    const periodo = form.querySelector('#periodo');
    const email = form.querySelector('#email');
    const curso = form.querySelector('#curso');

    let isValid = true;

    // Required field checks
    if (!nome?.value.trim()) {
      showFieldError(nome, 'Informe seu nome completo.');
      isValid = false;
    }

    if (!matricula?.value.trim()) {
      showFieldError(matricula, 'Informe sua matrícula.');
      isValid = false;
    } else {
      // RF02 - Unicidade da Matrícula
      const registered = JSON.parse(localStorage.getItem('nexus_registered_users') || '[]');
      const isDuplicate = registered.some(u => u.matricula === matricula.value.trim());
      if (isDuplicate) {
        showFieldError(matricula, 'Esta matrícula já está cadastrada no sistema.');
        isValid = false;
      }
    }

    if (periodo && periodo.value === '') {
      showFieldError(periodo, 'Selecione o período.');
      isValid = false;
    }

    if (!email?.value.trim()) {
      showFieldError(email, 'Informe seu e-mail.');
      isValid = false;
    } else if (!isInstitutionalEmail(email.value.trim())) {
      showFieldError(email, 'Utilize seu e-mail institucional (@ufla.br ou @estudante.ufla.br).');
      isValid = false;
    }

    if (curso && curso.value === '') {
      showFieldError(curso, 'Selecione seu curso.');
      isValid = false;
    }

    if (isValid) {
      const btn = form.querySelector('button[type="submit"]');
      const emailVal = email.value.trim();
      const nomeVal = nome.value.trim();
      const matriculaVal = matricula.value.trim();
      
      if (btn) {
        btn.textContent = 'PROCESSANDO...';
        btn.disabled = true;
        
        setTimeout(() => {
          // Add to mock registered users
          const registered = JSON.parse(localStorage.getItem('nexus_registered_users') || '[]');
          registered.push({ matricula: matriculaVal, email: emailVal, name: nomeVal });
          localStorage.setItem('nexus_registered_users', JSON.stringify(registered));

          // Hide form & form header
          form.style.display = 'none';
          const header = document.getElementById('cadastroFormHeader');
          if (header) header.style.display = 'none';

          // Show confirmation card (RF04)
          const confirmCard = document.getElementById('emailConfirmCard');
          const confirmEmailAddress = document.getElementById('confirmEmailAddress');
          if (confirmEmailAddress) confirmEmailAddress.textContent = emailVal;
          if (confirmCard) confirmCard.style.display = 'block';

          // Set up button listener for simulated activation click (RF05)
          const simulateBtn = document.getElementById('btnSimulateActivate');
          if (simulateBtn) {
            simulateBtn.addEventListener('click', () => {
              simulateBtn.textContent = 'ATIVANDO CONTA...';
              simulateBtn.disabled = true;
              
              // Automatically log in (saves name, matricula, email, perfil to localStorage)
              localStorage.setItem('nexus_user_name', nomeVal);
              localStorage.setItem('nexus_user_matricula', matriculaVal);
              localStorage.setItem('nexus_user_email', emailVal);
              localStorage.setItem('nexus_user_perfil', 'estudante');
              
              setTimeout(() => {
                window.location.href = 'estudante.html';
              }, 1000);
            });
          }
        }, 1200);
      }
    }
  });
}

/* ---- Login Form ---- */
function initLoginForm() {
  const form = document.getElementById('loginForm');
  if (!form) return;

  const perfilRadios = form.querySelectorAll('input[name="loginPerfil"]');
  const matriculaInput = form.querySelector('#loginMatricula');
  const matriculaGroup = matriculaInput?.closest('.form-group');

  function toggleMatriculaVisibility() {
    const selectedPerfil = form.querySelector('input[name="loginPerfil"]:checked')?.value;
    if (selectedPerfil === 'estudante') {
      if (matriculaGroup) matriculaGroup.style.display = 'block';
    } else {
      if (matriculaGroup) matriculaGroup.style.display = 'none';
      if (matriculaInput) matriculaInput.value = ''; // clear value so it doesn't cause issues
    }
  }

  // Listen for changes
  perfilRadios.forEach(radio => radio.addEventListener('change', toggleMatriculaVisibility));
  
  // Initial check
  toggleMatriculaVisibility();

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    clearErrors(form);

    const nome = form.querySelector('#loginNome');
    const matricula = form.querySelector('#loginMatricula');
    const email = form.querySelector('#loginEmail');
    const senha = form.querySelector('#loginSenha');

    let isValid = true;

    const selectedPerfil = form.querySelector('input[name="loginPerfil"]:checked')?.value || 'estudante';

    if (!nome?.value.trim()) {
      showFieldError(nome, 'Informe seu nome completo.');
      isValid = false;
    }

    if (selectedPerfil === 'estudante' && !matricula?.value.trim()) {
      showFieldError(matricula, 'Informe sua matrícula.');
      isValid = false;
    }

    if (!email?.value.trim()) {
      showFieldError(email, 'Informe seu e-mail.');
      isValid = false;
    } else if (!isInstitutionalEmail(email.value.trim())) {
      showFieldError(email, 'Utilize seu e-mail institucional (@ufla.br ou @estudante.ufla.br).');
      isValid = false;
    }

    if (!senha?.value.trim()) {
      showFieldError(senha, 'Informe sua senha.');
      isValid = false;
    } else if (senha.value.length < 6) {
      showFieldError(senha, 'A senha deve ter pelo menos 6 caracteres.');
      isValid = false;
    }

    if (isValid) {
      const btn = form.querySelector('button[type="submit"]');
      const perfil = form.querySelector('input[name="loginPerfil"]:checked')?.value || 'estudante';
      
      const nameVal = nome ? nome.value.trim() : '';
      const matriculaVal = matricula ? matricula.value.trim() : '';
      const emailVal = email ? email.value.trim() : '';
      
      // Save to localStorage for dynamic portal headers
      localStorage.setItem('nexus_user_name', nameVal);
      localStorage.setItem('nexus_user_matricula', matriculaVal);
      localStorage.setItem('nexus_user_email', emailVal);
      localStorage.setItem('nexus_user_perfil', perfil);

      if (btn) {
        btn.textContent = 'ENTRANDO...';
        btn.disabled = true;
        setTimeout(() => {
          btn.textContent = 'CONECTADO ✓';
          setTimeout(() => {
            let redirectUrl = 'estudante.html';
            if (perfil === 'professor') {
              redirectUrl = 'revisor.html';
            } else if (perfil === 'admin') {
              redirectUrl = 'admin.html';
            }
            window.location.href = redirectUrl;
          }, 1000);
        }, 1500);
      }
    }
  });
}

/* ---- Helpers ---- */
function showFieldError(input, message) {
  if (!input) return;
  input.classList.add('is-error');

  const group = input.closest('.form-group');
  if (!group) return;

  // Show existing hint or create a new one
  let hint = group.querySelector('.form-hint');
  if (hint) {
    hint.textContent = message;
    hint.classList.add('is-error');
    hint.style.display = 'flex';
  } else {
    hint = document.createElement('span');
    hint.className = 'form-hint is-error';
    hint.textContent = message;
    group.appendChild(hint);
  }
}

function clearErrors(form) {
  form.querySelectorAll('.is-error').forEach(el => {
    el.classList.remove('is-error');
  });
  form.querySelectorAll('.form-hint.is-error').forEach(el => {
    el.style.display = 'none';
  });
}

/* ---- Simulated Downloads for Prototype ---- */
function setupSimulatedDownloads() {
  const downloadBtns = document.querySelectorAll('.btn-baixar-doc');
  downloadBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      const filename = btn.getAttribute('data-filename') || 'documento.pdf';
      
      let content = `NEXUS — SISTEMA DE SUBMISSÕES CIENTÍFICAS DA UFLA (CONGRESSO 2026)\n\n`;
      content += `Documento: ${filename}\n`;
      content += `------------------------------------------------------------\n\n`;
      content += `Este é um modelo de documento ou formulário oficial do Congresso NEXUS 2026.\n`;
      content += `O arquivo oficial correspondente a "${filename}" estará disponível para download direto no sistema em breve.\n\n`;
      content += `Para fins de homologação e testes do protótipo frontend, este arquivo placeholder foi gerado dinamicamente através de um Blob no navegador.\n\n`;
      content += `Nexus Corp & UFLA — 2026`;
      
      const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    });
  });
}

/* ---- Database Seeder for Testing ---- */
function initDatabaseSeeder() {
  const seedBtn = document.getElementById('btn-seed-db');
  if (!seedBtn) return;

  seedBtn.addEventListener('click', (e) => {
    e.preventDefault();
    
    // Seed Registered Users
    const mockRegisteredUsers = [
      { matricula: '202310123', email: 'maria.silva@estudante.ufla.br', name: 'Maria Silva' },
      { matricula: '10001', email: 'prof.almeida@ufla.br', name: 'Prof. Dr. R. Almeida' },
      { matricula: '90001', email: 'admin.mendes@ufla.br', name: 'Profa. Dra. C. Mendes' }
    ];
    localStorage.setItem('nexus_registered_users', JSON.stringify(mockRegisteredUsers));

    // Seed Submissions
    const mockSubmissoes = [
      {
        id: 'NEXUS-2026-1001',
        titulo: 'Estudo das Propriedades Mecânicas de Compósitos Biodegradáveis baseados em Amido',
        resumo: 'Este trabalho apresenta um estudo detalhado sobre o desenvolvimento e caracterização de filmes compósitos biodegradáveis obtidos a partir de amido de milho termoplástico reforçado com nanofibras de celulose. Foram avaliadas as propriedades mecânicas, térmicas e de barreira à umidade dos filmes produzidos.',
        categoria: 'pibic',
        orientador: 'prof.almeida@ufla.br',
        coautores: [{ nome: 'Junior Costa', email: 'junior.costa@estudante.ufla.br' }],
        status: 'Em Avaliação',
        conflito: true,
        conflitoRegra: 'Revisor padrão (Prof. Dr. R. Almeida) é o orientador do trabalho',
        dataSubmissao: new Date(Date.now() - 3600000 * 24).toISOString(),
        ultimaAtualizacao: new Date(Date.now() - 3600000 * 23).toISOString(),
        autorNome: 'Maria Silva',
        autorMatricula: '202310123',
        revisorNome: '',
        revisorEmail: '',
        statusHistory: [
          { statusAnterior: 'Recebido', statusNovo: 'Em Análise', dataHora: new Date(Date.now() - 3600000 * 24).toISOString(), justificativa: 'Trabalho recebido pela comissão e encaminhado para análise preliminar.' },
          { statusAnterior: 'Em Análise', statusNovo: 'Em Avaliação', dataHora: new Date(Date.now() - 3600000 * 23).toISOString(), justificativa: 'Conflito detectado. Bloqueio automático de revisor.' }
        ],
        rodadas: [
          {
            rodada: 1,
            arquivoNome: 'propriedades_mecanicas_starch_v1.pdf',
            dataEnvio: new Date(Date.now() - 3600000 * 24).toISOString(),
            parecer: '',
            comentarios: ''
          }
        ]
      },
      {
        id: 'NEXUS-2026-1002',
        titulo: 'Algoritmos Genéticos Aplicados na Otimização de Rotas de Ônibus Urbanos em Lavras',
        resumo: 'Este artigo propõe um modelo matemático e uma heurística baseada em algoritmos genéticos para otimização de rotas de transporte público urbano. O objetivo é minimizar o tempo de viagem dos usuários e os custos operacionais da concessionária local.',
        categoria: 'pibic',
        orientador: 'prof.santos@ufla.br',
        coautores: [{ nome: 'Carla Dias', email: 'carla.dias@estudante.ufla.br' }],
        status: 'Aprovado',
        conflito: false,
        dataSubmissao: new Date(Date.now() - 3600000 * 24 * 3).toISOString(),
        ultimaAtualizacao: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
        autorNome: 'Gabriel Souza',
        autorMatricula: '202310456',
        revisorNome: 'Prof. Dr. R. Almeida',
        revisorEmail: 'prof.almeida@ufla.br',
        statusHistory: [
          { statusAnterior: 'Recebido', statusNovo: 'Em Análise', dataHora: new Date(Date.now() - 3600000 * 24 * 3).toISOString(), justificativa: 'Recebido com sucesso.' },
          { statusAnterior: 'Em Análise', statusNovo: 'Em Avaliação', dataHora: new Date(Date.now() - 3600000 * 24 * 3 + 12000).toISOString(), justificativa: 'Trabalho distribuído para revisão cega.' },
          { statusAnterior: 'Em Avaliação', statusNovo: 'Aprovado', dataHora: new Date(Date.now() - 3600000 * 24 * 2).toISOString(), justificativa: 'Parecer técnico enviado pelo revisor: Aprovado sem restrições.' }
        ],
        rodadas: [
          {
            rodada: 1,
            arquivoNome: 'otimizacao_rotas_geneticos.pdf',
            dataEnvio: new Date(Date.now() - 3600000 * 24 * 3).toISOString(),
            parecer: 'Aprovado',
            comentarios: 'O trabalho apresenta excelente rigor metodológico. A formulação matemática do algoritmo genético está descrita de forma clara e os resultados experimentais demonstram viabilidade prática para o transporte público de Lavras. Recomendamos a aprovação para apresentação oral no congresso.',
            ratings: { clareza: '9', rigor: '9', consistência: '8', aderencia: '9', qualidade: '9' }
          }
        ]
      },
      {
        id: 'NEXUS-2026-1003',
        titulo: 'Desenvolvimento de um Sistema Web IoT para Monitoramento e Controle de Estufas Agrícolas',
        resumo: 'Este projeto de extensão relata o desenvolvimento e implantação de um sistema IoT modular e de baixo custo para pequenos produtores familiares da região. O sistema monitora umidade do solo, temperatura e luminosidade, permitindo acionamento remoto de irrigação por app.',
        categoria: 'extensao',
        orientador: 'prof.lima@ufla.br',
        coautores: [],
        status: 'Correções Necessárias',
        conflito: false,
        dataSubmissao: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
        ultimaAtualizacao: new Date(Date.now() - 3600000 * 24 * 1).toISOString(),
        autorNome: 'Lucas Oliveira',
        autorMatricula: '202310789',
        revisorNome: 'Prof. Dr. R. Almeida',
        revisorEmail: 'prof.almeida@ufla.br',
        statusHistory: [
          { statusAnterior: 'Recebido', statusNovo: 'Em Análise', dataHora: new Date(Date.now() - 3600000 * 24 * 2).toISOString(), justificativa: 'Submissão inicial cadastrada.' },
          { statusAnterior: 'Em Análise', statusNovo: 'Em Avaliação', dataHora: new Date(Date.now() - 3600000 * 24 * 2 + 12000).toISOString(), justificativa: 'Designado para revisão pelo professor R. Almeida.' },
          { statusAnterior: 'Em Avaliação', statusNovo: 'Correções Necessárias', dataHora: new Date(Date.now() - 3600000 * 24 * 1).toISOString(), justificativa: 'Parecer técnico indica a necessidade de correções estruturais antes de reavaliar.' }
        ],
        rodadas: [
          {
            rodada: 1,
            arquivoNome: 'estufas_iot_extensao.pdf',
            dataEnvio: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
            parecer: 'Correções Necessárias',
            comentarios: 'O projeto é de grande valia e apresenta um excelente impacto potencial para pequenos agricultores. Entretanto, a descrição metodológica e a análise de impacto social estão extremamente vagas no texto atual. É fundamental detalhar como os beneficiários locais participaram da modelagem e se houve transferência de conhecimento de fato. Além disso, os indicadores de sustentabilidade financeira da estufa a longo prazo devem ser especificados. Por favor, amplie consideravelmente a seção 3 e a seção 4 do artigo, atendendo a estes quesitos para podermos reavaliar o trabalho na próxima rodada.',
            ratings: { impacto: '6', articulacao: '7', pertinencia: '8', indicadores: '5', participacao: '5' }
          }
        ]
      },
      {
        id: 'NEXUS-2026-1004',
        titulo: 'Análise de Sentimentos em Redes Sociais durante Eventos Acadêmicos na UFLA',
        resumo: 'Este trabalho realiza a coleta e classificação de postagens em redes sociais públicas com a hashtag do congresso anterior da UFLA. Utilizando técnicas de processamento de linguagem natural (NLP), avaliou-se a polaridade das reações discentes (positiva, negativa, neutra).',
        categoria: 'bic-junior',
        orientador: 'prof.souza@ufla.br',
        coautores: [],
        status: 'Em Avaliação',
        conflito: false,
        dataSubmissao: new Date(Date.now() - 3600000 * 1).toISOString(),
        ultimaAtualizacao: new Date(Date.now() - 3600000 * 1).toISOString(),
        autorNome: 'Bruno Rezende',
        autorMatricula: '202410222',
        revisorNome: 'Prof. Dr. R. Almeida',
        revisorEmail: 'prof.almeida@ufla.br',
        statusHistory: [
          { statusAnterior: 'Recebido', statusNovo: 'Em Análise', dataHora: new Date(Date.now() - 3600000 * 1).toISOString(), justificativa: 'Submissão registrada.' },
          { statusAnterior: 'Em Análise', statusNovo: 'Em Avaliação', dataHora: new Date(Date.now() - 3600000 * 1 + 12000).toISOString(), justificativa: 'Trabalho direcionado para a fila de avaliação técnica.' }
        ],
        rodadas: [
          {
            rodada: 1,
            arquivoNome: 'sentimentos_redes_sociais.pdf',
            dataEnvio: new Date(Date.now() - 3600000 * 1).toISOString(),
            parecer: '',
            comentarios: ''
          }
        ]
      }
    ];
    localStorage.setItem('nexus_submissoes', JSON.stringify(mockSubmissoes));

    // Seed Notifications
    const mockNotificacoes = [
      {
        tipo: 'CONFLITO',
        title: 'Conflito de interesse detectado',
        desc: 'O revisor Prof. Almeida possui conflito de interesse com o trabalho NEXUS-2026-1001 (orientação/coautoria).',
        time: 'há 10 minutos',
        unread: true,
        timestamp: new Date(Date.now() - 600000).toISOString()
      },
      {
        tipo: 'SUBMISSÃO',
        title: 'Novo trabalho submetido',
        desc: 'O trabalho "Análise de Sentimentos em Redes Sociais" foi submetido na categoria BIC Júnior.',
        time: 'há 1 hora',
        unread: true,
        timestamp: new Date(Date.now() - 3600000).toISOString()
      },
      {
        tipo: 'PARECER',
        title: 'Parecer técnico enviado',
        desc: 'O parecer para o trabalho NEXUS-2026-1003 foi emitido como "Correções Necessárias".',
        time: 'há 1 dia',
        unread: false,
        timestamp: new Date(Date.now() - 3600000 * 24).toISOString()
      },
      {
        tipo: 'SUBMISSÃO',
        title: 'Trabalho Aprovado',
        desc: 'O revisor enviou o parecer final do trabalho NEXUS-2026-1002, definindo como APROVADO.',
        time: 'há 2 dias',
        unread: false,
        timestamp: new Date(Date.now() - 3600000 * 24 * 2).toISOString()
      }
    ];
    localStorage.setItem('nexus_notificacoes', JSON.stringify(mockNotificacoes));

    // Seed default configurations
    const mockConfig = {
      abertura: '2026-01-04',
      encerramento: '2026-05-31',
      alertHours: 48,
      minChars: 1000,
      maxCoautores: 5,
      edital: 'Prezados participantes, o Congresso de Iniciação Científica 2026 da UFLA receberá submissões nas modalidades PIBIC, BIC Jr, Ensino e Extensão. Os trabalhos devem seguir o template oficial disponível na plataforma NEXUS. O prazo final para submissão é 31 de maio de 2026.'
    };
    localStorage.setItem('nexus_config', JSON.stringify(mockConfig));
    localStorage.setItem('nexus_config_alert_hours', '48');

    // Fill form fields with Maria Silva's info as helper
    const loginNome = document.getElementById('loginNome');
    const loginMatricula = document.getElementById('loginMatricula');
    const loginEmail = document.getElementById('loginEmail');
    const loginSenha = document.getElementById('loginSenha');
    
    if (loginNome) loginNome.value = 'Maria Silva';
    if (loginMatricula) loginMatricula.value = '202310123';
    if (loginEmail) loginEmail.value = 'maria.silva@estudante.ufla.br';
    if (loginSenha) loginSenha.value = '123456';
    
    // Set checked profile to Student
    const studentRadio = document.querySelector('input[name="loginPerfil"][value="estudante"]');
    if (studentRadio) studentRadio.checked = true;

    alert('Banco de dados de teste carregado com sucesso!\nOs campos do formulário foram preenchidos com os dados da estudante Maria Silva.\n\nVocê também pode alterar o "Perfil de Acesso" para Professor ou Admin e utilizar as credenciais descritas no banner.');
  });
}

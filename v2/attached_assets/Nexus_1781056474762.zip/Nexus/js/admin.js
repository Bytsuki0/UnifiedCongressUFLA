/* ============================================
   NEXUS Admin Portal — JavaScript
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {

  // Safe localStorage helper
  function getLocalStorageItem(key, defaultValue) {
    try {
      const val = localStorage.getItem(key);
      if (!val) return defaultValue;
      const parsed = JSON.parse(val);
      if (Array.isArray(parsed)) {
        return parsed.filter(item => item !== null && item !== undefined);
      }
      return parsed;
    } catch (e) {
      console.error(`Error parsing localStorage key "${key}":`, e);
      return defaultValue;
    }
  }

  // Premium Toast Notification helper
  function showToast(message, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let iconSvg = '';
    if (type === 'success') {
      iconSvg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
          <polyline points="22 4 12 14.01 9 11.01"></polyline>
        </svg>
      `;
    } else if (type === 'danger') {
      iconSvg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="12" y1="8" x2="12" y2="12"></line>
          <line x1="12" y1="16" x2="12.01" y2="16"></line>
        </svg>
      `;
    } else if (type === 'warning') {
      iconSvg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
          <line x1="12" y1="9" x2="12" y2="13"></line>
          <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
      `;
    } else {
      iconSvg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="12" y1="16" x2="12" y2="12"></line>
          <line x1="12" y1="8" x2="12.01" y2="8"></line>
        </svg>
      `;
    }

    toast.innerHTML = `
      ${iconSvg}
      <span style="font-family: var(--font-family-title);">${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('hide');
      toast.addEventListener('animationend', () => {
        toast.remove();
      });
    }, 4000);
  }

  // Load dynamic user info from localStorage
  const loggedName = localStorage.getItem('nexus_user_name');
  const loggedMatricula = localStorage.getItem('nexus_user_matricula');
  
  if (loggedName) {
    const userNameEl = document.querySelector('.user-info .user-name');
    const userAvatarEl = document.querySelector('.user-info .user-avatar');
    if (userNameEl) userNameEl.textContent = loggedName;
    if (userAvatarEl) {
      const parts = loggedName.trim().split(/\s+/);
      const initials = parts.length >= 2 ? (parts[0][0] + parts[parts.length - 1][0]).toUpperCase() : parts[0][0].toUpperCase();
      userAvatarEl.textContent = initials;
    }
  }
  if (loggedMatricula) {
    const userMetaEl = document.querySelector('.user-info .user-meta');
    if (userMetaEl) userMetaEl.textContent = `Reg: ${loggedMatricula} · Comissão · UFLA`;
  }

  // ---- Sidebar Navigation ----
  const navItems = document.querySelectorAll('.sidebar-nav .nav-item[data-section]');
  const sections = document.querySelectorAll('.section');

  function navigateTo(sectionId) {
    // Update nav items
    navItems.forEach(item => {
      item.classList.toggle('active', item.dataset.section === sectionId);
    });

    // Update sections
    sections.forEach(section => {
      section.classList.toggle('active', section.id === sectionId);
    });
  }

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const sectionId = item.dataset.section;
      if (sectionId) {
        navigateTo(sectionId);
      }
    });
  });

  // Handle hash navigation
  if (window.location.hash) {
    const hash = window.location.hash.substring(1);
    const matchingItem = document.querySelector(`.nav-item[data-section="${hash}"]`);
    if (matchingItem) {
      navigateTo(hash);
    }
  }



  // ---- Search / Filter (Audit Table) ----
  const searchInput = document.getElementById('audit-search');
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      const query = searchInput.value.toLowerCase().trim();
      const rows = document.querySelectorAll('#audit-table tbody tr');

      rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(query) ? '' : 'none';
      });
    });
  }

  // ---- Filter Button Toggle ----
  const filterBtn = document.getElementById('btn-filtros');
  const auditFilterPanel = document.getElementById('audit-filter-panel');
  if (filterBtn && auditFilterPanel) {
    filterBtn.addEventListener('click', () => {
      if (auditFilterPanel.style.display === 'none') {
        auditFilterPanel.style.display = 'flex';
        filterBtn.classList.add('active');
        filterBtn.style.background = 'var(--gray-100)';
      } else {
        auditFilterPanel.style.display = 'none';
        filterBtn.classList.remove('active');
        filterBtn.style.background = 'transparent';
      }
    });
  }

  const auditFilterCbs = document.querySelectorAll('.audit-filter-cb');
  auditFilterCbs.forEach(cb => {
    cb.addEventListener('change', renderAdminPanel);
  });

  // ---- Export Button ----
  const exportBtn = document.getElementById('btn-exportar');
  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      // Export submissions as a simulated CSV download
      const submissoes = getLocalStorageItem('nexus_submissoes', []);
      if (submissoes.length === 0) {
        showToast('Não há dados de submissão para exportar.', 'danger');
        return;
      }
      
      let csvContent = 'Protocolo,Titulo,Categoria,Orientador,Autor,Matricula,Status,UltimaAtualizacao\n';
      submissoes.forEach(s => {
        csvContent += `"${s.id}","${s.titulo.replace(/"/g, '""')}","${s.categoria.toUpperCase()}","${s.orientador}","${s.autorNome}","${s.autorMatricula}","${s.status}","${s.ultimaAtualizacao}"\n`;
      });
      
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', 'nexus_auditoria_submissoes.csv');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    });
  }



  // ---- Config: Alert Hours Equivalence ----
  const alertInput = document.getElementById('alert-hours');
  const alertDisplay = document.getElementById('alert-equiv');
  if (alertInput && alertDisplay) {
    function updateEquiv() {
      const hours = parseInt(alertInput.value) || 0;
      const days = (hours / 24).toFixed(0);
      alertDisplay.textContent = `EQUIVALE A ${hours}h ≈ ${days} dias`;
    }
    alertInput.addEventListener('input', updateEquiv);
  }

  // ---- Config: Save ----
  const saveBtn = document.getElementById('btn-save-config');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      const abertura = document.getElementById('cfg-abertura')?.value || '2026-01-04';
      const encerramento = document.getElementById('cfg-encerramento')?.value || '2026-05-31';
      const alertHours = document.getElementById('alert-hours')?.value || '48';
      const minChars = document.getElementById('cfg-min-chars')?.value || '1000';
      const maxCoautores = document.getElementById('cfg-max-coautores')?.value || '5';
      const edital = document.getElementById('cfg-edital')?.value || '';

      const linkTemplateWord = document.getElementById('cfg-link-template-word')?.value || '';
      const linkTemplateLatex = document.getElementById('cfg-link-template-latex')?.value || '';
      const linkFormPesquisa = document.getElementById('cfg-link-form-pesquisa')?.value || '';
      const linkFormExtensao = document.getElementById('cfg-link-form-extensao')?.value || '';
      const linkFormEnsino = document.getElementById('cfg-link-form-ensino')?.value || '';
      const linkArqEdital = document.getElementById('cfg-link-arq-edital')?.value || '';
      const linkArqManual = document.getElementById('cfg-link-arq-manual')?.value || '';
      const linkArqDiretrizes = document.getElementById('cfg-link-arq-diretrizes')?.value || '';
      const linkArqEtica = document.getElementById('cfg-link-arq-etica')?.value || '';
      const linkArqModelo = document.getElementById('cfg-link-arq-modelo')?.value || '';

      const config = {
        abertura,
        encerramento,
        alertHours: parseInt(alertHours),
        minChars: parseInt(minChars),
        maxCoautores: parseInt(maxCoautores),
        edital,
        links: {
          templateWord: linkTemplateWord,
          templateLatex: linkTemplateLatex,
          formPesquisa: linkFormPesquisa,
          formExtensao: linkFormExtensao,
          formEnsino: linkFormEnsino,
          arqEdital: linkArqEdital,
          arqManual: linkArqManual,
          arqDiretrizes: linkArqDiretrizes,
          arqEtica: linkArqEtica,
          arqModelo: linkArqModelo
        }
      };

      localStorage.setItem('nexus_config', JSON.stringify(config));
      // Save global configuration parameter to be used by revisor.js
      localStorage.setItem('nexus_config_alert_hours', alertHours);

      alert('foi salvo a configuração');
    });
  }

  // ---- Config: Restore Defaults ----
  const restoreBtn = document.getElementById('btn-restore-default');
  if (restoreBtn) {
    restoreBtn.addEventListener('click', () => {
      if (confirm('Restaurar todas as configurações para os valores padrão?')) {
        const abertura = document.getElementById('cfg-abertura');
        const encerramento = document.getElementById('cfg-encerramento');
        if (abertura) abertura.value = '2026-01-04';
        if (encerramento) encerramento.value = '2026-05-31';

        if (alertInput) {
          alertInput.value = '48';
          if (alertDisplay) alertDisplay.textContent = 'EQUIVALE A 48h ≈ 2 dias';
        }

        const minChars = document.getElementById('cfg-min-chars');
        const maxCoautores = document.getElementById('cfg-max-coautores');
        if (minChars) minChars.value = '1000';
        if (maxCoautores) maxCoautores.value = '5';

        const edital = document.getElementById('cfg-edital');
        if (edital) edital.value = 'Prezados participantes, o Congresso de Iniciação Científica 2026 da UFLA receberá submissões nas modalidades PIBIC, BIC Jr, Ensino e Extensão. Os trabalhos devem seguir o template oficial disponível na plataforma NEXUS. O prazo final para submissão é 31 de maio de 2026.';

        // Save defaults
        const config = {
          abertura: '2026-01-04',
          encerramento: '2026-05-31',
          alertHours: 48,
          minChars: 1000,
          maxCoautores: 5,
          edital: edital ? edital.value : '',
          links: {
            templateWord: 'https://example.com/template.docx',
            templateLatex: 'https://example.com/template.zip',
            formPesquisa: 'https://example.com/form_pesquisa.pdf',
            formExtensao: 'https://example.com/form_extensao.pdf',
            formEnsino: 'https://example.com/form_ensino.pdf',
            arqEdital: 'https://example.com/edital.pdf',
            arqManual: 'https://example.com/manual.pdf',
            arqDiretrizes: 'https://example.com/diretrizes.pdf',
            arqEtica: 'https://example.com/etica.pdf',
            arqModelo: 'https://example.com/modelo.docx'
          }
        };
        localStorage.setItem('nexus_config', JSON.stringify(config));
        localStorage.setItem('nexus_config_alert_hours', '48');

        // Check checkboxes
        document.querySelectorAll('.config-toggle-row input[type="checkbox"]').forEach(t => t.checked = true);

        showToast('Configurações restauradas ao padrão.', 'success');
      }
    });
  }

  const markReadBtn = document.getElementById('mark-all-read');
  if (markReadBtn) {
    markReadBtn.addEventListener('click', () => {
      let notificacoes = getLocalStorageItem('nexus_notificacoes', []);
      notificacoes = notificacoes.map(n => {
        if (n) n.unread = false;
        return n;
      });
      localStorage.setItem('nexus_notificacoes', JSON.stringify(notificacoes));
      window.dispatchEvent(new Event('storage'));
      renderAdminPanel();
    });
  }

  // ---- Notif Filter Logic ----
  const btnFiltrarNotif = document.getElementById('btn-filtrar-notif');
  const notifFilterPanel = document.getElementById('notif-filter-panel');
  if (btnFiltrarNotif && notifFilterPanel) {
    btnFiltrarNotif.addEventListener('click', () => {
      if (notifFilterPanel.style.display === 'none') {
        notifFilterPanel.style.display = 'flex';
        btnFiltrarNotif.classList.add('active');
        btnFiltrarNotif.style.background = 'var(--gray-100)';
      } else {
        notifFilterPanel.style.display = 'none';
        btnFiltrarNotif.classList.remove('active');
        btnFiltrarNotif.style.background = 'transparent';
      }
    });
  }

  const filterCbs = document.querySelectorAll('.notif-filter-cb');
  filterCbs.forEach(cb => {
    cb.addEventListener('change', renderAdminPanel);
  });

  // ---- Refresh Notifications ----
  const refreshBtn = document.getElementById('btn-atualizar');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      refreshBtn.style.opacity = '0.5';
      refreshBtn.style.pointerEvents = 'none';
      setTimeout(() => {
        refreshBtn.style.opacity = '1';
        refreshBtn.style.pointerEvents = '';
        renderAdminPanel();
      }, 600);
    });
  }

  // ---- Load configurations ----
  loadConfig();

  // ---- Load notifications, conflicts and audit table ----
  renderAdminPanel();

  // Polling simulation loop to update metrics, table, conflicts, and notifications in real-time
  setInterval(() => {
    runStatusSimulation();
    renderAdminPanel();
  }, 4000);

  // ---- Admin Panel Data Rendering ----
  function renderAdminPanel() {
    const submissoes = getLocalStorageItem('nexus_submissoes', []);
    
    // 1. Calculate Metrics
    const totalCount = submissoes.filter(s => s).length;
    const reviewCount = submissoes.filter(s => s && s.status === 'Em Avaliação').length;
    const approvedCount = submissoes.filter(s => s && (s.status === 'Aprovado' || s.status === 'Aprovado com Correções')).length;
    const rejectedCount = submissoes.filter(s => s && (s.status === 'Reprovado' || s.status === 'Desclassificado')).length;

    const cards = document.querySelectorAll('.stat-card-admin');
    if (cards.length >= 4) {
      cards[0].querySelector('.stat-value').textContent = totalCount;
      cards[1].querySelector('.stat-value').textContent = reviewCount;
      cards[2].querySelector('.stat-value').textContent = approvedCount;
      cards[3].querySelector('.stat-value').textContent = rejectedCount;
    }

    // 2. Render Audit Table
    const emptyState = document.getElementById('admin-empty-state');
    const auditContainer = document.getElementById('admin-audit-container');
    const tableBody = document.querySelector('#audit-table tbody');

    if (totalCount === 0) {
      if (emptyState) emptyState.style.display = 'flex';
      if (auditContainer) auditContainer.style.display = 'none';
    } else {
      if (emptyState) emptyState.style.display = 'none';
      if (auditContainer) auditContainer.style.display = 'block';

      if (tableBody) {
        tableBody.innerHTML = '';
        
        // Apply Audit Filters
        const activeAuditFilters = Array.from(document.querySelectorAll('.audit-filter-cb:checked'));
        const statusFilters = activeAuditFilters.filter(cb => cb.dataset.group === 'status').map(cb => cb.value.toLowerCase());
        const catFilters = activeAuditFilters.filter(cb => cb.dataset.group === 'categoria').map(cb => cb.value.toLowerCase());
        
        let filteredSubs = submissoes.filter(sub => {
          if (!sub) return false;
          let matchStatus = statusFilters.length === 0 || statusFilters.includes((sub.status || '').toLowerCase());
          let matchCat = catFilters.length === 0 || catFilters.includes((sub.categoria || '').toLowerCase());
          return matchStatus && matchCat;
        });

        filteredSubs.forEach(sub => {
          if (!sub) return;
          const row = document.createElement('tr');

          let statusClass = 'badge-gray';
          if (sub.status === 'Recebido') statusClass = 'badge-gray';
          else if (sub.status === 'Em Análise') statusClass = 'badge-navy';
          else if (sub.status === 'Em Avaliação') statusClass = 'badge-amber';
          else if (sub.status === 'Aprovado') statusClass = 'badge-green';
          else if (sub.status === 'Reprovado' || sub.status === 'Desclassificado') statusClass = 'badge-red';
          else if (sub.status === 'Aprovado com Correções' || sub.status === 'Correções Necessárias') statusClass = 'badge-blue';

          const revisorStr = sub.revisorNome ? sub.revisorNome : (sub.conflito ? '<span style="color:var(--red-600); font-weight:bold;">[Conflito]</span>' : '<span style="color:var(--amber-600);">Pendente</span>');

          // Action buttons
          let actionHtml = '';
          const hasParecer = sub.status === 'Aprovado' || sub.status === 'Reprovado' || sub.status === 'Desclassificado' || sub.status === 'Aprovado com Correções' || sub.status === 'Correções Necessárias';
          if (hasParecer) {
            actionHtml = `<button class="btn-danger-sm btn-reverter" data-id="${sub.id}">REVERTER PARECER</button>`;
          } else if (sub.conflito) {
            actionHtml = `<button class="btn btn-outline btn-sm btn-reatribuir-manual" data-id="${sub.id}">REATRIBUIR</button>`;
          } else {
            actionHtml = `<span style="color:var(--color-text-muted); font-size:var(--fs-caption);">Sem ações</span>`;
          }

          row.innerHTML = `
            <td style="padding: var(--space-4) var(--space-5);"><strong style="color: var(--color-primary);">${sub.id}</strong></td>
            <td style="padding: var(--space-4) var(--space-5);">
              <span class="work-title" style="font-weight:var(--fw-semibold);">${sub.titulo || ''}</span>
              <span class="work-author" style="font-size:var(--fs-caption); color:var(--color-text-muted);">${sub.autorNome || ''} (Matrícula: ${sub.autorMatricula || ''})</span>
            </td>
            <td style="padding: var(--space-4) var(--space-5);"><span class="badge badge-gray">${(sub.categoria || '').toUpperCase()}</span></td>
            <td style="padding: var(--space-4) var(--space-5);">${revisorStr}</td>
            <td style="padding: var(--space-4) var(--space-5); text-align: center;"><span class="round-number">${(sub.rodadas || []).length}</span></td>
            <td style="padding: var(--space-4) var(--space-5);"><span class="badge ${statusClass}">${sub.status}</span></td>
            <td style="padding: var(--space-4) var(--space-5);">${actionHtml}</td>
          `;
          tableBody.appendChild(row);
        });

        // Re-attach revert buttons
        tableBody.querySelectorAll('.btn-reverter').forEach(btn => {
          btn.addEventListener('click', (e) => {
            e.preventDefault();
            const subId = btn.getAttribute('data-id');
            revertParecer(subId);
          });
        });

        // Re-attach manual reassign buttons
        tableBody.querySelectorAll('.btn-reatribuir-manual').forEach(btn => {
          btn.addEventListener('click', (e) => {
            e.preventDefault();
            const subId = btn.getAttribute('data-id');
            reassignRevisor(subId);
          });
        });

        // Maintain search filter if active
        const searchInput = document.getElementById('audit-search');
        if (searchInput && searchInput.value) {
          searchInput.dispatchEvent(new Event('input'));
        }
      }
    }

    // 3. Render Conflicts
    const conflictEmptyState = document.getElementById('admin-conflitos-empty-state');
    const conflictList = document.getElementById('admin-conflitos-list');
    const conflictedSubs = submissoes.filter(s => s && s.conflito === true);

    if (conflictedSubs.length === 0) {
      if (conflictEmptyState) conflictEmptyState.style.display = 'flex';
      if (conflictList) conflictList.style.display = 'none';
    } else {
      if (conflictEmptyState) conflictEmptyState.style.display = 'none';
      if (conflictList) conflictList.style.display = 'flex';

      if (conflictList) {
        conflictList.innerHTML = '';
        conflictedSubs.forEach(sub => {
          if (!sub) return;
          const card = document.createElement('div');
          card.className = 'conflict-card border-red';
          card.innerHTML = `
            <div class="conflict-card-body">
              <div class="conflict-card-header">
                <span class="badge badge-solid-red">C-CRÍTICO</span>
                <span class="conflict-id">Trabalho: ${sub.id}</span>
              </div>
              <div class="conflict-detail">
                <div class="conflict-detail-label">Título do Trabalho</div>
                <div class="conflict-detail-value">${sub.titulo}</div>
              </div>
              <div class="conflict-detail">
                <div class="conflict-detail-label">Revisor Bloqueado</div>
                <div class="conflict-detail-value"><span class="reviewer-blocked">Prof. Dr. R. Almeida (prof.almeida@ufla.br)</span></div>
              </div>
              <div class="conflict-detail">
                <div class="conflict-detail-label">Regra Violada</div>
                <div class="conflict-detail-value">${sub.conflitoRegra}</div>
              </div>
              <div class="conflict-quote">
                "O orientador informado (${sub.orientador}) ou co-autores coincidem com o revisor padrão de sistema."
              </div>
            </div>
            <div class="conflict-card-actions">
              <div class="toggle-row">
                <span class="toggle-label-text">Aprovar Exceção</span>
                <span class="toggle-hint">Permitir este revisor</span>
                <label class="toggle" style="margin-top: 4px;">
                  <input type="checkbox" class="conflito-excecao-toggle" data-id="${sub.id}">
                  <span class="toggle-slider"></span>
                </label>
              </div>
              <button class="btn-reatribuir btn-reatribuir-manual" data-id="${sub.id}" style="width: 100%;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                REATRIBUIR REVISOR
              </button>
            </div>
          `;
          conflictList.appendChild(card);
        });

        // Exception checkbox handler
        conflictList.querySelectorAll('.conflito-excecao-toggle').forEach(chk => {
          chk.addEventListener('change', (e) => {
            if (chk.checked) {
              const subId = chk.getAttribute('data-id');
              approveConflictException(subId);
            }
          });
        });

        // Reassign revisor button handler
        conflictList.querySelectorAll('.btn-reatribuir').forEach(btn => {
          btn.addEventListener('click', (e) => {
            e.preventDefault();
            const subId = btn.getAttribute('data-id');
            reassignRevisor(subId);
          });
        });
      }
    }

    // 4. Render Notifications Feed
    const notifContainer = document.getElementById('admin-notif-list');
    const notificacoes = getLocalStorageItem('nexus_notificacoes', []);

    const countUnread = notificacoes.filter(n => n && n.unread === true).length;
    const countTotal = notificacoes.filter(n => n).length;

    const notifCounter = document.querySelector('.notif-counter');
    const newDot = document.querySelector('.notif-counter .dot-new');
    if (notifCounter) {
      notifCounter.innerHTML = `<span class="dot-new" style="display: ${countUnread > 0 ? 'inline-block' : 'none'};"></span> ${countUnread} NOVAS · ${countTotal} NO TOTAL`;
    }

    if (markReadBtn) {
      markReadBtn.style.display = countUnread > 0 ? 'inline-block' : 'none';
    }

    if (notifContainer) {
      notifContainer.innerHTML = '';
      if (countTotal === 0) {
        notifContainer.innerHTML = `
          <div class="notif-item" style="justify-content: center; padding: var(--space-6); color: var(--color-text-secondary);">
            Nenhum evento registrado no feed.
          </div>
        `;
      } else {
        // Apply Filters
        const activeFilters = Array.from(document.querySelectorAll('.notif-filter-cb:checked')).map(cb => cb.value);
        let typeFilters = activeFilters.filter(f => f !== 'unread');
        let unreadFilter = activeFilters.includes('unread');

        let filteredNotifs = notificacoes.filter(n => {
          if (!n) return false;
          let typeMatch = typeFilters.length === 0 || typeFilters.includes(n.tipo);
          let unreadMatch = !unreadFilter || n.unread === true;
          return typeMatch && unreadMatch;
        });

        if (filteredNotifs.length === 0) {
          notifContainer.innerHTML = `
            <div class="notif-item" style="justify-content: center; padding: var(--space-6); color: var(--color-text-secondary);">
              Nenhum evento corresponde aos filtros selecionados.
            </div>
          `;
        } else {
          filteredNotifs.forEach((n, idx) => {
            let badgeClass = 'badge-solid-blue';
            if (n.tipo === 'SUBMISSÃO') badgeClass = 'badge-solid-green';
            else if (n.tipo === 'CONFLITO') badgeClass = 'badge-solid-red';
            else if (n.tipo === 'PRAZO') badgeClass = 'badge-solid-amber';

            const item = document.createElement('div');
            item.className = `notif-item ${n.unread ? 'unread' : ''}`;
            
            item.innerHTML = `
              <div class="notif-badge-col">
                <span class="badge ${badgeClass}">${n.tipo}</span>
                ${n.unread ? '<span class="notif-unread-dot"></span>' : ''}
              </div>
              <div class="notif-body">
                <div class="notif-title">${n.title}</div>
                <div class="notif-desc">${n.desc}</div>
              </div>
              <span class="notif-time">${n.time}</span>
            `;
            notifContainer.appendChild(item);
          });
        }
      }
    }
  }

  // ---- Reverter Parecer formal (RF37 / RNF04) ----
  function revertParecer(subId) {
    const justificativa = prompt(`Justificativa Formal para Reverter Parecer do trabalho ${subId}:\n(Obrigatório para o log de auditoria)`);
    if (justificativa === null) return; // cancelled
    if (!justificativa.trim()) {
      showToast('A justificativa é obrigatória para a reversão.', 'danger');
      return;
    }

    const submissoes = getLocalStorageItem('nexus_submissoes', []);
    const subIndex = submissoes.findIndex(s => s.id === subId);
    if (subIndex === -1) return;

    const sub = submissoes[subIndex];
    const previousStatus = sub.status;
    const newStatus = 'Em Avaliação';

    // Clear latest round evaluation
    if (sub.rodadas && sub.rodadas.length > 0) {
      const latestRound = sub.rodadas[sub.rodadas.length - 1];
      latestRound.parecer = '';
      latestRound.comentarios = '';
      latestRound.status = '';
      if (latestRound.ratings) delete latestRound.ratings;
    }

    sub.status = newStatus;
    sub.ultimaAtualizacao = new Date().toISOString();

    // Log in history
    sub.statusHistory = sub.statusHistory || [];
    sub.statusHistory.push({
      statusAnterior: previousStatus,
      statusNovo: newStatus,
      dataHora: new Date().toISOString(),
      justificativa: `REVERSÃO FORMAL: "${justificativa}" (Executado por Profa. Dra. C. Mendes)`
    });

    submissoes[subIndex] = sub;
    localStorage.setItem('nexus_submissoes', JSON.stringify(submissoes));

    // Create notification
    const notificacoes = getLocalStorageItem('nexus_notificacoes', []);
    notificacoes.unshift({
      tipo: 'SUBMISSÃO',
      title: 'Decisão de parecer revertida',
      desc: `O parecer do trabalho ${sub.id} foi revertido de volta a "Em Avaliação". Justificativa: ${justificativa}`,
      time: 'agora',
      unread: true,
      timestamp: new Date().toISOString()
    });
    localStorage.setItem('nexus_notificacoes', JSON.stringify(notificacoes));

    showToast('Parecer revertido com sucesso!', 'success');
    renderAdminPanel();
  }

  // ---- Approve Conflict Exception ----
  function approveConflictException(subId) {
    const submissoes = getLocalStorageItem('nexus_submissoes', []);
    const subIndex = submissoes.findIndex(s => s.id === subId);
    if (subIndex === -1) return;

    const sub = submissoes[subIndex];
    sub.conflito = false;
    // Assign standard reviewer anyway
    sub.revisorEmail = 'prof.almeida@ufla.br';
    sub.revisorNome = 'Prof. Dr. R. Almeida';

    sub.statusHistory = sub.statusHistory || [];
    sub.statusHistory.push({
      statusAnterior: sub.status,
      statusNovo: sub.status,
      dataHora: new Date().toISOString(),
      justificativa: 'Exceção de conflito aprovada pela comissão. Revisor padrão mantido.'
    });

    submissoes[subIndex] = sub;
    localStorage.setItem('nexus_submissoes', JSON.stringify(submissoes));

    const notificacoes = getLocalStorageItem('nexus_notificacoes', []);
    notificacoes.unshift({
      tipo: 'SUBMISSÃO',
      title: 'Exceção de conflito aprovada',
      desc: `A comissão organizadora aprovou exceção para o trabalho ${sub.id}, designando Prof. Almeida.`,
      time: 'agora',
      unread: true,
      timestamp: new Date().toISOString()
    });
    localStorage.setItem('nexus_notificacoes', JSON.stringify(notificacoes));

    showToast('Exceção de conflito aprovada!', 'success');
    renderAdminPanel();
  }

  // ---- Reassign Revisor manually ----
  function reassignRevisor(subId) {
    const newName = prompt('Digite o nome do novo revisor a ser designado:\n(Ex: Prof. Dr. J. Silva)');
    if (newName === null) return;
    if (!newName.trim()) {
      showToast('Nome do revisor é obrigatório.', 'danger');
      return;
    }

    const submissoes = getLocalStorageItem('nexus_submissoes', []);
    const subIndex = submissoes.findIndex(s => s.id === subId);
    if (subIndex === -1) return;

    const sub = submissoes[subIndex];
    sub.conflito = false;
    sub.revisorNome = newName.trim();
    sub.revisorEmail = 'joao.silva@ufla.br'; // Simulated new reviewer email

    sub.statusHistory = sub.statusHistory || [];
    sub.statusHistory.push({
      statusAnterior: sub.status,
      statusNovo: sub.status,
      dataHora: new Date().toISOString(),
      justificativa: `Reatribuição de revisor concluída: trabalho designado a ${sub.revisorNome}.`
    });

    submissoes[subIndex] = sub;
    localStorage.setItem('nexus_submissoes', JSON.stringify(submissoes));

    const notificacoes = getLocalStorageItem('nexus_notificacoes', []);
    notificacoes.unshift({
      tipo: 'SUBMISSÃO',
      title: 'Trabalho reatribuído',
      desc: `O trabalho ${sub.id} foi reatribuído para o revisor ${sub.revisorNome}.`,
      time: 'agora',
      unread: true,
      timestamp: new Date().toISOString()
    });
    localStorage.setItem('nexus_notificacoes', JSON.stringify(notificacoes));

    showToast(`Trabalho reatribuído para ${sub.revisorNome}!`, 'success');
    renderAdminPanel();
  }

  // ---- Load configurations ----
  function loadConfig() {
    const config = getLocalStorageItem('nexus_config', null);
    if (config) {
      try {
        if (document.getElementById('cfg-abertura') && config.abertura) document.getElementById('cfg-abertura').value = config.abertura;
        if (document.getElementById('cfg-encerramento') && config.encerramento) document.getElementById('cfg-encerramento').value = config.encerramento;
        if (document.getElementById('alert-hours') && config.alertHours) {
          document.getElementById('alert-hours').value = config.alertHours;
          if (alertDisplay) {
            const days = (config.alertHours / 24).toFixed(0);
            alertDisplay.textContent = `EQUIVALE A ${config.alertHours}h ≈ ${days} dias`;
          }
        }
        if (document.getElementById('cfg-min-chars') && config.minChars) document.getElementById('cfg-min-chars').value = config.minChars;
        if (document.getElementById('cfg-max-coautores') && config.maxCoautores) document.getElementById('cfg-max-coautores').value = config.maxCoautores;
        if (document.getElementById('cfg-edital') && config.edital) document.getElementById('cfg-edital').value = config.edital;

        if (config.links) {
          if (document.getElementById('cfg-link-template-word')) document.getElementById('cfg-link-template-word').value = config.links.templateWord || '';
          if (document.getElementById('cfg-link-template-latex')) document.getElementById('cfg-link-template-latex').value = config.links.templateLatex || '';
          if (document.getElementById('cfg-link-form-pesquisa')) document.getElementById('cfg-link-form-pesquisa').value = config.links.formPesquisa || '';
          if (document.getElementById('cfg-link-form-extensao')) document.getElementById('cfg-link-form-extensao').value = config.links.formExtensao || '';
          if (document.getElementById('cfg-link-form-ensino')) document.getElementById('cfg-link-form-ensino').value = config.links.formEnsino || '';
          if (document.getElementById('cfg-link-arq-edital')) document.getElementById('cfg-link-arq-edital').value = config.links.arqEdital || '';
          if (document.getElementById('cfg-link-arq-manual')) document.getElementById('cfg-link-arq-manual').value = config.links.arqManual || '';
          if (document.getElementById('cfg-link-arq-diretrizes')) document.getElementById('cfg-link-arq-diretrizes').value = config.links.arqDiretrizes || '';
          if (document.getElementById('cfg-link-arq-etica')) document.getElementById('cfg-link-arq-etica').value = config.links.arqEtica || '';
          if (document.getElementById('cfg-link-arq-modelo')) document.getElementById('cfg-link-arq-modelo').value = config.links.arqModelo || '';
        }
      } catch (e) {
        console.error('Error loading config', e);
      }
    }
  }

  // ---- Status Advancement Simulation Loop ----
  function runStatusSimulation() {
    const submissoes = getLocalStorageItem('nexus_submissoes', []);
    let changed = false;
    
    const now = new Date();
    submissoes.forEach(sub => {
      if (!sub) return;
      const timeRef = new Date(sub.ultimaAtualizacao || sub.dataSubmissao);
      const elapsedSeconds = (now - timeRef) / 1000;
      
      if (sub.status === 'Recebido' && elapsedSeconds >= 12) {
        sub.status = 'Em Análise';
        sub.ultimaAtualizacao = new Date().toISOString();
        sub.statusHistory = sub.statusHistory || [];
        sub.statusHistory.push({
          statusAnterior: 'Recebido',
          statusNovo: 'Em Análise',
          dataHora: new Date().toISOString(),
          justificativa: 'Trabalho recebido pela comissão e encaminhado para análise preliminar de formato.'
        });
        
        const notificacoes = getLocalStorageItem('nexus_notificacoes', []);
        notificacoes.unshift({
          tipo: 'PRAZO',
          title: 'Trabalho em análise',
          desc: `O trabalho "${sub.titulo}" (ID: ${sub.id}) passou para status "Em Análise".`,
          time: 'agora',
          unread: true,
          timestamp: new Date().toISOString()
        });
        localStorage.setItem('nexus_notificacoes', JSON.stringify(notificacoes));
        
        changed = true;
      } else if (sub.status === 'Em Análise' && elapsedSeconds >= 12) {
        sub.status = 'Em Avaliação';
        sub.ultimaAtualizacao = new Date().toISOString();
        
        // Conflict checking (RF13 / RF31)
        const advisorEmail = sub.orientador;
        const coauthorEmails = (sub.coautores || []).filter(c => c && c.email).map(c => c.email);
        const isConflicted = advisorEmail === 'prof.almeida@ufla.br' || coauthorEmails.includes('prof.almeida@ufla.br');
        
        if (isConflicted) {
          sub.revisorEmail = '';
          sub.revisorNome = '';
          sub.conflito = true;
          sub.conflitoRegra = 'Orientador ou coautor cadastrado como revisor';
          
          const notificacoes = getLocalStorageItem('nexus_notificacoes', []);
          notificacoes.unshift({
            tipo: 'CONFLITO',
            title: 'Conflito de interesse detectado',
            desc: `O revisor Prof. Almeida possui conflito de interesse com o trabalho ${sub.id} (orientação/coautoria).`,
            time: 'agora',
            unread: true,
            timestamp: new Date().toISOString()
          });
          localStorage.setItem('nexus_notificacoes', JSON.stringify(notificacoes));
        } else {
          sub.revisorEmail = 'prof.almeida@ufla.br';
          sub.revisorNome = 'Prof. Dr. R. Almeida';
        }
        
        sub.statusHistory = sub.statusHistory || [];
        sub.statusHistory.push({
          statusAnterior: 'Em Análise',
          statusNovo: 'Em Avaliação',
          dataHora: new Date().toISOString(),
          justificativa: isConflicted ? 'Conflito detectado. Bloqueio automático de revisor.' : 'Trabalho distribuído para revisão cega de parecer técnico.'
        });
        
        changed = true;
      }
    });
    
    if (changed) {
      localStorage.setItem('nexus_submissoes', JSON.stringify(submissoes));
    }
  }

  // ---- Sidebar Footer (Logout) ----
  const logoutBtn = document.querySelector('.sidebar-footer .nav-item');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      if (confirm('Deseja sair do painel administrativo?')) {
        localStorage.removeItem('nexus_user_name');
        localStorage.removeItem('nexus_user_matricula');
        localStorage.removeItem('nexus_user_email');
        localStorage.removeItem('nexus_user_perfil');
        window.location.href = 'login.html';
      }
    });
  }

});

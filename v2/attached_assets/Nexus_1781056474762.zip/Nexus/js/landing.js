/* ============================================
   NEXUS — Landing Page Scripts
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {

  /* ---- Header Scroll Effect ---- */
  const header = document.querySelector('.landing-header');
  let lastScroll = 0;

  function handleHeaderScroll() {
    const scrollY = window.scrollY;

    if (scrollY > 20) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }

    lastScroll = scrollY;
  }

  window.addEventListener('scroll', handleHeaderScroll, { passive: true });
  handleHeaderScroll(); // run on load

  /* ---- Scroll Reveal (IntersectionObserver) ---- */
  const revealElements = document.querySelectorAll('.reveal');

  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          revealObserver.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.15,
      rootMargin: '0px 0px -40px 0px'
    });

    revealElements.forEach(el => revealObserver.observe(el));
  } else {
    // Fallback: reveal everything immediately
    revealElements.forEach(el => el.classList.add('revealed'));
  }

  /* ---- Smooth Scroll for Anchor Links ---- */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', (e) => {
      const targetId = anchor.getAttribute('href');
      if (targetId === '#') return;

      const targetEl = document.querySelector(targetId);
      if (targetEl) {
        e.preventDefault();
        targetEl.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });

  /* ---- Parallax-like subtle movement on hero ---- */
  const hero = document.querySelector('.hero');
  if (hero) {
    window.addEventListener('scroll', () => {
      const scrollY = window.scrollY;
      const heroHeight = hero.offsetHeight;

      if (scrollY < heroHeight) {
        const progress = scrollY / heroHeight;
        const heroText = hero.querySelector('.hero-text');
        const heroFeatures = hero.querySelector('.hero-features');

        if (heroText) {
          heroText.style.transform = `translateY(${progress * 30}px)`;
          heroText.style.opacity = 1 - progress * 0.6;
        }
        if (heroFeatures) {
          heroFeatures.style.transform = `translateY(${progress * 20}px)`;
          heroFeatures.style.opacity = 1 - progress * 0.5;
        }
      }
    }, { passive: true });
  }

  /* ---- Simulated Downloads for Prototype ---- */
  function setupSimulatedDownloads() {
    const downloadBtns = document.querySelectorAll('.btn-baixar-doc');
    downloadBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        const filename = btn.getAttribute('data-filename') || 'documento.pdf';
        
        let content = `NEXUS — SISTEMA DE SUBMISSÕES CIENTÍFICAS DA UFLA (CONGRESSO 2026)\n\n`;
        content += `Documento: ${filename}\n`;
        content += `------------------------------------------------------------\n\n`;
        content += `Este é um modelo de documento ou formulário oficial do Congresso NEXUS 2026.\n`;
        content += `O arquivo oficial correspondente a "${filename}" estará disponível para download direto no sistema em breve.\n\n`;
        content += `Para fins de homologação e testes do protótipo frontend, este arquivo placeholder foi gerado dinamicamente através de um Blob no navegador.\n\n`;
        content += `Nexus Corp & UFLA — 2026`;
        
        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      });
    });
  }

  setupSimulatedDownloads();

});

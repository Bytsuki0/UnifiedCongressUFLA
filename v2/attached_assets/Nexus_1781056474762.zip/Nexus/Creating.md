```python
markdown_content = """# NEXUS CORP · UFLA 2026

## GUIA DE DESENVOLVIMENTO
### Padrões de Estrutura e Criação de Páginas

**Plataforma de Submissões Científicas — Congresso UFLA** *Versão 1.0 · Junho 2026 · HTML · CSS · JavaScript*

---

## 1. Visão Geral do Projeto

O NEXUS é uma plataforma de submissões científicas da Universidade Federal de Lavras (UFLA), desenvolvida em HTML, CSS e JavaScript puros — sem frameworks front-end externos. O site possui cinco páginas principais com identidade visual coesa baseada em tema verde escuro, design de cartões e uma linguagem de componentes consistente.

### 1.1 Estrutura de Arquivos do Repositório


```

```text
Markdown generated successfully.


```

nexus/
├── index.html          → Landing page pública
├── login.html          → Autenticação e cadastro
├── cadastro.html       → Formulário de criação de conta
├── estudante.html      → Dashboard do estudante (SPA)
├── revisor.html        → Dashboard do revisor
├── admin.html          → Painel administrativo
│
├── css/
│   ├── landing.css     → Estilos da landing page
│   ├── auth.css        → Estilos das telas de auth
│   └── estudante.css   → Estilos do dashboard
│
└── js/
├── landing.js      → Scripts da landing page
├── auth.js         → Scripts de autenticação
└── estudante.js    → Lógica do dashboard

```

### 1.2 Categorias de Páginas

O projeto divide suas páginas em três categorias funcionais:

| Categoria | Arquivos | CSS Associado | JS Associado |
| :--- | :--- | :--- | :--- |
| Landing / Pública | `index.html` | `css/landing.css` | `js/landing.js` |
| Autenticação | `login.html`, `cadastro.html` | `css/auth.css` | `js/auth.js` |
| Dashboard (SPA) | `estudante.html`, `revisor.html`, `admin.html` | `css/estudante.css` | `js/estudante.js` |

---

## 2. Sistema de Design (Design Tokens)

Toda a interface é construída sobre variáveis CSS declaradas em `:root`. Ao adicionar novas páginas, essas variáveis devem ser referenciadas no lugar de valores hexadecimais ou numéricos fixos.

### 2.1 Paleta de Cores

```css
:root {
  /* ── Cores Principais ── */
  --nexus-verde:         #0D5C3A;   /* Verde principal, headers, botões */
  --nexus-verde-med:     #1A7A50;   /* Verde médio, sidebar */
  --nexus-verde-claro:   #4CAF80;   /* Hover, destaques ativos */
  --nexus-verde-escuro:  #092E1F;   /* Gradiente profundo, left panel */

  /* ── Escala de Cinza ── */
  --gray-50:  #FAFAFA;
  --gray-100: #F5F5F5;
  --gray-200: #EEEEEE;
  --gray-400: #BDBDBD;
  --gray-600: #757575;
  --gray-800: #424242;
  --gray-900: #1E1E1E;

  /* ── Variáveis Semânticas ── */
  --color-bg:              #FFFFFF;
  --color-text:            var(--gray-900);
  --color-text-secondary:  var(--gray-600);
  --color-primary:         var(--nexus-verde);

  /* ── Azuis (alertas, info) ── */
  --blue-50:  #E3F2FD;
  --blue-600: #1E88E5;
  --blue-800: #1565C0;
}

```

> ⚠️ **Regra de Cor:** Nunca escreva cores hexadecimais diretamente no HTML ou CSS de uma nova página. Sempre use as variáveis CSS acima. Isso garante consistência visual e facilita futuras atualizações de tema.

### 2.2 Tipografia

```css
:root {
  /* ── Famílias ── */
  --font-family-base:   'Inter', 'Segoe UI', Arial, sans-serif;
  --font-family-title:  'Space Grotesk', 'Barlow', Arial, sans-serif;

  /* ── Escala de Tamanhos (rem) ── */
  --fs-xs:   0.75rem;   /* 12px — labels, metadados */
  --fs-sm:   0.875rem;  /* 14px — corpo secundário */
  --fs-base: 1rem;      /* 16px — corpo principal */
  --fs-md:   1.125rem;  /* 18px — subtítulos */
  --fs-h3:   1.25rem;   /* 20px — H3 */
  --fs-h2:   1.5rem;    /* 24px — H2 */
  --fs-h1:   2rem;      /* 32px — H1 */

  /* ── Pesos ── */
  --fw-regular:  400;
  --fw-semibold: 600;
  --fw-bold:     700;
  --fw-black:    900;

  /* ── Letter Spacing ── */
  --ls-label: 0.08em;   /* Usado em overlines e rótulos em caps */
}

```

### 2.3 Espaçamento e Bordas

```css
:root {
  /* ── Escala de Espaço ── */
  --space-1: 0.25rem;  --space-2: 0.5rem;
  --space-3: 0.75rem;  --space-4: 1rem;
  --space-5: 1.25rem;  --space-6: 1.5rem;
  --space-8: 2rem;     --space-10: 2.5rem;
  --space-12: 3rem;    --space-16: 4rem;

  /* ── Bordas Arredondadas ── */
  --radius-sm:  4px;
  --radius-md:  8px;
  --radius-lg:  12px;
  --radius-xl:  16px;
  --radius-full: 9999px;

  /* ── Sombras ── */
  --shadow-sm:  0 1px 3px rgba(0,0,0,0.08);
  --shadow-md:  0 4px 12px rgba(0,0,0,0.10);
  --shadow-lg:  0 8px 24px rgba(0,0,0,0.14);
}

```

---

## 3. Anatomia das Páginas por Categoria

### 3.1 Página de Landing (index.html)

A landing page é a vitrine pública do sistema. Sua estrutura é composta por seções empilhadas verticalmente dentro de um `<body class="landing-page">`.

```html
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="...">
  <title>Título da Página · NEXUS</title>
  <link rel="stylesheet" href="css/landing.css">
  </head>
<body class="landing-page">

  <header class="landing-header"> ... </header>

  <section class="nome-da-secao">
    <div class="nome-da-secao-inner"> ... </div>
  </section>

  <section class="cta-banner"> ... </section>

  <footer class="landing-footer"> ... </footer>

  <script src="js/landing.js"></script>
  </body>
</html>

```

#### Componentes obrigatórios da landing:

* Header com `.landing-header` (logo + nav com links ENTRAR, CADASTRAR-SE, COMISSÃO)
* Footer com `.landing-footer` (copyright + e-mail de suporte)
* Seções com class dupla: `.nome-secao` + wrapper interno `.nome-secao-inner`
* Animação de entrada via classe `.reveal` (ativada pelo `IntersectionObserver` em `landing.js`)

### 3.2 Páginas de Autenticação (login.html / cadastro.html)

As telas de autenticação usam um layout *split-screen* de duas colunas: painel esquerdo verde com informações institucionais e painel direito branco com o formulário.

```html
<html lang="pt-BR">
<head>
  <link rel="stylesheet" href="css/auth.css">
</head>
<body>
  <div class="login-wrapper">

    <aside class="login-left">
      <div class="login-left-logo"> ... </div>
      <div class="login-left-content">
        <h1 class="hero-title">...</h1>
        <div class="login-features"> ... </div>
      </div>
      <footer class="login-left-footer"> ... </footer>
    </aside>

    <main class="login-right">
      <div class="login-right-inner">
        <section class="login-form-section">
          <p class="section-overline">RÓTULO DA SEÇÃO</p>
          <h2 class="section-title">Título</h2>
          <p class="section-description">Descrição</p>
          <form id="meuForm" novalidate>
            </form>
        </section>
      </div>
    </main>

  </div>
  <script src="js/auth.js"></script>
</body>
</html>

```

### 3.3 Páginas de Dashboard (SPA — estudante, revisor, admin)

Os dashboards são Single-Page Applications (SPA) leves, onde a navegação entre seções é feita por JavaScript puro, sem recarregar a página. O layout combina uma sidebar fixa à esquerda com uma área de conteúdo principal dinâmica.

```html
<html lang="pt-BR">
<head>
  <link rel="stylesheet" href="css/estudante.css">
  </head>
<body>

  <aside class="sidebar">
    <a href="#" class="sidebar-logo"> ... </a>
    <nav class="sidebar-nav">
      <button class="nav-item active" data-section="dashboard">Dashboard</button>
      <button class="nav-item" data-section="nome-da-secao">Nome</button>
    </nav>
    <div class="sidebar-footer"> ... </div>
  </aside>

  <main class="main-content">
    <header class="top-bar"> ... </header>

    <div id="dashboard" class="section active">
      <div class="content-area"> ... </div>
    </div>

    <div id="nome-da-secao" class="section">
      <div class="content-area"> ... </div>
    </div>

  </main>

  <script src="js/estudante.js"></script>
</body>
</html>

```

---

## 4. Biblioteca de Componentes Reutilizáveis

Todos os elementos abaixo estão definidos nos arquivos CSS existentes e podem ser reaproveitados em novas páginas sem necessidade de adicionar estilos novos.

### 4.1 Botões (.btn)

```html
<a class="btn btn-primary">Ação Principal</a>
<a class="btn btn-ghost">Ação Fantasma</a>
<a class="btn btn-outline">Ação Secundária</a>
<a class="btn btn-outline-white">Sobre fundo escuro</a>

<a class="btn btn-primary btn-sm">Pequeno</a>
<a class="btn btn-primary btn-lg">Grande</a>
<a class="btn btn-primary btn-block">Largura total</a>

<a class="btn btn-primary">
  TEXTO
  <svg xmlns="[http://www.w3.org/2000/svg](http://www.w3.org/2000/svg)" width="16" height="16" ...>
    <path d="M5 12h14"/> <path d="m12 5 7 7-7 7"/>
  </svg>
</a>

```

### 4.2 Formulários

```html
<div class="form-group">
  <label class="form-label" for="campoId">Rótulo</label>
  <input type="text" id="campoId" class="form-input" placeholder="Exemplo">
  <span class="form-hint is-error" style="display:none;">Mensagem de erro</span>
</div>

<div class="form-group">
  <label class="form-label">Categoria</label>
  <select class="form-select">
    <option value="" disabled selected>Selecione</option>
    <option value="a">Opção A</option>
  </select>
</div>

<textarea class="form-textarea" rows="5" placeholder="..."></textarea>
<div class="char-counter" id="char-counter">0 / 230 palavras</div>

<div class="password-wrapper">
  <input type="password" class="form-input">
  <button type="button" class="password-toggle"> ... </button>
</div>

```

```html
<div class="feature-card">
  <div class="feature-icon"> <svg>...</svg> </div>
  <div class="feature-content">
    <div class="feature-title">Título</div>
    <div class="feature-desc">Descrição curta</div>
  </div>
</div>

<div class="step-card">
  <div class="step-card-header">
    <div class="step-number">01</div>
    <div class="step-info">
      <div class="step-title">Nome da Etapa</div>
      <div class="step-subtitle">Subtítulo opcional</div>
    </div>
  </div>
  </div>

<div class="dashboard-stat-card">
  <div class="stat-card-header">
    <span class="stat-card-title">RÓTULO</span>
    <div class="stat-card-icon"> <svg>...</svg> </div>
  </div>
  <div class="stat-card-value">42</div>
</div>

```

### 4.4 Alertas e Mensagens

```html
<div class="alert alert-danger">
  <svg>...</svg>
  <span><strong>Erro:</strong> Mensagem descritiva.</span>
</div>

<div class="alert alert-warning">
  <svg>...</svg>
  <span>Mensagem de aviso.</span>
</div>

<div class="empty-state">
  <div class="empty-state-icon"> <svg>...</svg> </div>
  <h3 class="empty-state-title">Nada aqui ainda</h3>
  <p class="empty-state-description">Descrição do estado vazio.</p>
  <button class="btn btn-primary btn-sm">AÇÃO</button>
</div>

```

### 4.5 Tabelas

```html
<div class="table-container">
  <table class="table">
    <thead>
      <tr>
        <th>COLUNA A</th>
        <th>COLUNA B</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Valor 1</td>
        <td>Valor 2</td>
      </tr>
    </tbody>
  </table>
</div>

```

### 4.6 Ícones SVG

O projeto usa exclusivamente ícones da biblioteca Lucide (SVG inline, sem dependência externa). Os atributos obrigatórios em todo ícone são:

```html
<svg
  xmlns="[http://www.w3.org/2000/svg](http://www.w3.org/2000/svg)"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
  width="18" height="18"
>
  </svg>

```

> ℹ️ **Uso de `stroke="currentColor"`:** o ícone herda automaticamente a cor do elemento pai. Isso significa que dentro de `.btn-primary` o ícone ficará branco, e dentro de `.nav-item` ficará com a cor do texto da nav — sem precisar definir cor explicitamente.

### 4.7 Overlines e Hierarquia de Texto

```html
<div class="page-overline">RÓTULO EM CAPS</div>   <h1 class="page-title">Título Principal</h1>      <p class="page-description">Parágrafo descritivo...</p>  <div class="section-overline">↓ SUBTÍTULO</div>
<h2 class="section-title">Título da Seção</h2>
<p class="section-description">Descrição...</p>

```

---

## 5. Lógica JavaScript — Padrões e Convenções

### 5.1 Navegação SPA no Dashboard

A navegação entre seções no dashboard é controlada pelo atributo `data-section`. Cada botão da sidebar aponta para a ID de uma `<div class="section">`. O JS ativa/desativa as seções via classe `.active`.

```javascript
// Padrão usado em estudante.js (e que deve ser replicado):

// 1. Seleciona todos os botões de navegação
const navItems = document.querySelectorAll('.nav-item[data-section]');
const sections = document.querySelectorAll('.section');

// 2. Adiciona listener em cada botão
navItems.forEach(btn => {
  btn.addEventListener('click', () => {
    const target = btn.dataset.section;

    // Remove active de todos
    navItems.forEach(n => n.classList.remove('active'));
    sections.forEach(s => s.classList.remove('active'));

    // Ativa o botão e seção alvo
    btn.classList.add('active');
    document.getElementById(target)?.classList.add('active');
  });
});

```

### 5.2 Gerenciamento de Estado Local

Por ser um projeto front-end puro (sem back-end ativo), o estado é armazenado em `localStorage`. Todo dado salvo segue a convenção de prefixo `nexus_`.

```javascript
// Convenções de chaves no localStorage:
// nexus_user       → objeto com dados do usuário logado
// nexus_submissions → array de submissões do estudante
// nexus_drafts      → rascunhos não enviados

// Salvar:
localStorage.setItem('nexus_submissions', JSON.stringify(arrayDeSubmissoes));

// Ler:
const subs = JSON.parse(localStorage.getItem('nexus_submissions') || '[]');

// ATENÇÃO: sempre use || '[]' ou || '{}' como fallback
// para evitar JSON.parse(null) que lança exceção.

```

### 5.3 Validação de Formulários

A validação segue o padrão: verificar campos no submit, marcar os inválidos com classe `.is-invalid` no input e exibir `.form-hint.is-error` correspondente.

```javascript
// Padrão de validação do projeto
function validarFormulario() {
  let valido = true;

  const campo = document.getElementById('meuCampo');
  const erro  = document.getElementById('erro-meuCampo');

  if (!campo.value.trim()) {
    campo.classList.add('is-invalid');
    erro.style.display = 'flex';
    valido = false;
  } else {
    campo.classList.remove('is-invalid');
    erro.style.display = 'none';
  }

  return valido;
}

// Validação de e-mail institucional (padrão do projeto)
function isEmailInstitucional(email) {
  return /@(estudante\\.)?ufla\\.br$/.test(email.toLowerCase());
}

```

### 5.4 Animação de Entrada (Reveal)

A landing page usa `IntersectionObserver` para revelar elementos quando entram na viewport. Aplique a classe `.reveal` (e `.reveal-delay-N` para escalonamento) em qualquer elemento de uma nova seção.

```javascript
// Já implementado em js/landing.js — basta usar as classes:

// HTML:
// <div class="reveal">Elemento animado</div>
// <div class="reveal reveal-delay-1">Atraso 100ms</div>
// <div class="reveal reveal-delay-2">Atraso 200ms</div>
// <div class="reveal reveal-delay-3">Atraso 300ms</div>

// O script em landing.js adiciona a classe .revealed quando
// o elemento fica visível. O CSS cuida da transição opacity/translateY.

```

### 5.5 Geração de Número de Protocolo

Submissões recebem um número de protocolo gerado no front-end seguindo o padrão `NEXUS-ANO-NNNN`.

```javascript
// Função padrão para gerar protocolo
function gerarProtocolo() {
  const ano = new Date().getFullYear();
  const num = String(Math.floor(Math.random() * 9000) + 1000);
  return `NEXUS-${ano}-${num}`;
}
// Exemplo: NEXUS-2026-4273

```

---

## 6. Adicionando uma Nova Página — Passo a Passo

> ⚠️ **Antes de criar:** Identifique a categoria da nova página (Landing, Auth ou Dashboard SPA) antes de começar. A categoria define qual CSS importar, qual estrutura HTML base usar e qual JS reutilizar ou criar.

### 6.1 Nova Seção em Dashboard Existente

Este é o cenário mais comum: adicionar uma funcionalidade nova (ex: 'Configurações') ao dashboard de um perfil já existente.

#### Passo 1 — Adicionar o botão na sidebar

```html
<button class="nav-item" data-section="configuracoes">
  <svg ...> </svg>
  Configurações
</button>

```

#### Passo 2 — Criar a div de seção

```html
<div id="configuracoes" class="section">
  <div class="content-area">

    <div class="page-header">
      <div class="page-overline">PERFIL</div>
      <h1 class="page-title">Configurações</h1>
      <p class="page-description">Gerencie seus dados institucionais.</p>
    </div>

    </div>
</div>

```

#### Passo 3 — Confirmar que o JS cobre a nova seção

Se o script já usa o seletor genérico `.nav-item[data-section]` (padrão do projeto), a navegação funcionará automaticamente. Verifique em `estudante.js` e não é necessário nenhuma alteração adicional.

### 6.2 Nova Página HTML Independente

Para criar uma página completamente nova (ex: `politica-privacidade.html`, `faq.html`), siga este checklist:

* Definir a categoria: Landing (pública) ou Auth (login/cadastro)?
* Copiar o esqueleto HTML da categoria correspondente (seções 3.1 ou 3.2 deste guia)
* Importar apenas o CSS da categoria: `landing.css` para Landing, `auth.css` para Auth
* Replicar header e footer do `index.html` sem modificação
* Usar somente classes existentes dos arquivos CSS — não criar folhas de estilo novas sem necessidade
* Vincular no menu: adicionar o `<a href="nova-pagina.html">` no `<nav class="header-nav">` de todas as páginas
* Criar o JS apenas se houver interatividade específica; caso contrário, reutilizar `js/landing.js`

### 6.3 Novo Perfil de Usuário (novo dashboard)

Para adicionar um perfil inédito (ex: `coorientador.html`), o processo é:

* Duplicar `estudante.html` como ponto de partida
* Renomear o arquivo: `nomeperfil.html`
* Criar `css/nomeperfil.css` copiando `estudante.css` como base
* Criar `js/nomeperfil.js` copiando `estudante.js` como base
* Adaptar o `<title>`, a `.top-bar` (nome do portal) e o `.user-info`
* Remover seções irrelevantes para o novo perfil e adicionar as específicas
* Atualizar o redirecionamento em `js/auth.js` para incluir o novo valor de perfil no radio de login

---

## 7. Regras e Boas Práticas

### 7.1 Obrigatório

* Todo HTML deve iniciar com `<!DOCTYPE html>` e `<html lang="pt-BR">`
* Todo `<input>`, `<textarea>` e `<select>` deve ter id único e `<label>` correspondente com `for="mesmo-id"`
* Formulários devem sempre ter atributo `novalidate` (a validação é feita via JS)
* SVG inline: sempre incluir `xmlns`, `viewBox`, `fill="none"`, `stroke="currentColor"`
* Links externos: usar `target="_blank" rel="noopener noreferrer"`
* Imagens (se usadas): incluir atributo `alt` descritivo
* O arquivo CSS de uma página deve ser o último `<link>` do `<head>`
* O arquivo JS de uma página deve ser o último elemento antes de `</body>`

### 7.2 Proibido

* Não usar frameworks CSS externos (Bootstrap, Tailwind, etc.) — o sistema de design é próprio
* Não usar cores hexadecimais hard-coded — sempre usar variáveis CSS
* Não criar IDs duplicados em uma mesma página
* Não usar `<table>` para layout — apenas para dados tabulares
* Não usar inline styles para propriedades que já têm classe CSS definida
* Não usar `alert()` ou `console.log()` em código enviado para produção

### 7.3 Acessibilidade Básica

* Botões sem texto visível devem ter `aria-label` descritivo
* Modais devem ter `role="dialog"` e `aria-modal="true"`
* Contraste mínimo de 4.5:1 entre texto e fundo (o verde `#0D5C3A` sobre branco já atende)
* Navegação por teclado: elementos interativos devem ser focáveis (`:focus-visible` estilizado)

### 7.4 Nomenclatura CSS

O projeto usa BEM simplificado. Siga o padrão:

| Tipo | Formato | Exemplo |
| --- | --- | --- |
| Bloco (componente) | `.nome-bloco` | `.feature-card, .step-card` |
| Elemento (filho) | `.nome-bloco-elemento` | `.feature-card-icon, .step-card-header` |
| Modificador (variante) | `.nome--modificador` | `.btn--disabled, .nav-item--active` |
| Utilitário | `.mb-N, .mt-N` | `.mb-6, .mt-8` |
| Estado JS | `.is-estado` | `.is-invalid, .is-loading, .is-active` |

---

## 8. Checklist de Nova Página

Use esta lista de verificação antes de fazer merge de uma nova página no repositório:

* [ ] Categoria identificada (Landing / Auth / Dashboard)
* [ ] Esqueleto HTML correto para a categoria
* [ ] `lang="pt-BR"` no `<html>`
* [ ] `<meta charset>` e `<meta viewport>` presentes
* [ ] `<title>` no formato: Título · NEXUS
* [ ] `<meta description>` preenchida
* [ ] CSS correto importado (`landing.css`, `auth.css` ou específico)
* [ ] Header e footer idênticos aos das outras páginas da mesma categoria
* [ ] Todos os inputs com id + label com for
* [ ] Nenhuma cor hexadecimal hard-coded
* [ ] Nenhum ID duplicado
* [ ] SVGs inline com atributos completos
* [ ] Script JS vinculado antes de `</body>`
* [ ] Navegação SPA: data-section e div#id correspondente (apenas dashboards)
* [ ] Link para a nova página adicionado ao menu de todas as outras páginas relevantes
* [ ] Testado em viewport mobile (375px) e desktop (1280px)

---

## 9. Índice Rápido de Classes CSS

| Classe | Arquivo | Uso |
| --- | --- | --- |
| `.landing-header` | `landing.css` | Header público com logo + nav |
| `.landing-footer` | `landing.css` | Footer público simples |
| `.hero` | `landing.css` | Seção hero de 2 colunas (texto + cards) |
| `.feature-card` | `landing.css` | Cartão de funcionalidade com ícone |
| `.reveal / .reveal-delay-N` | `landing.css` | Animação de entrada via IntersectionObserver |
| `.cta-banner` | `landing.css` | Faixa de chamada para ação |
| `.section-overline` | `landing.css` | Rótulo pequeno em caps acima de título |
| `.login-wrapper` | `auth.css` | Container split-screen da tela auth |
| `.login-left / .login-right` | `auth.css` | Painéis esquerdo/direito da auth |
| `.login-form-section` | `auth.css` | Container do formulário no painel direito |
| `.profile-select-btn` | `auth.css` | Botão radio estilizado para seleção de perfil |
| `.sidebar` | `estudante.css` | Barra lateral de navegação |
| `.nav-item` | `estudante.css` | Item de navegação da sidebar |
| `.main-content` | `estudante.css` | Área principal do dashboard |
| `.top-bar` | `estudante.css` | Barra superior com título e info do usuário |
| `.section / .section.active` | `estudante.css` | Seção SPA (oculta / visível) |
| `.content-area` | `estudante.css` | Wrapper de conteúdo com padding |
| `.page-header` | `estudante.css` | Cabeçalho de seção (overline + título + desc) |
| `.step-card` | `estudante.css` | Cartão de etapa numerada em formulários |
| `.dashboard-stat-card` | `estudante.css` | Card de métrica no painel de estatísticas |
| `.drop-zone` | `estudante.css` | Área de upload de arquivo com drag-and-drop |
| `.empty-state` | `estudante.css` | Estado vazio com ícone, título e ação |
| `.table-container / .table` | `estudante.css` | Container + tabela de dados com scroll |
| `.modal-backdrop` | `estudante.css` | Overlay de modal com blur |
| `.btn btn-primary` | `global` | Botão verde principal |
| `.btn btn-outline` | `global` | Botão com borda |
| `.btn btn-ghost` | `global` | Botão transparente |
| `.btn btn-block` | `global` | Botão de largura total |
| `.form-group` | `global` | Agrupador de campo (label + input + hint) |
| `.form-input / .form-select / .form-textarea` | `global` | Elementos de formulário |
| `.form-hint.is-error` | `global` | Mensagem de erro inline de formulário |
| `.alert alert-danger` | `global` | Alerta vermelho |
| `.alert alert-warning` | `global` | Alerta amarelo |

---

**NEXUS Corp — Plataforma de Submissões Científicas** *Universidade Federal de Lavras · Congresso UFLA 2026*
"""

with open("nexus_guia_desenvolvimento.md", "w", encoding="utf-8") as f:
f.write(markdown_content)

print("Markdown generated successfully.")

```
O seu ficheiro Markdown (.md) está pronto
[file-tag: code-generated-file-0-1781029151845166658]

Transformei com sucesso todo o conteúdo do **Guia de Desenvolvimento do NEXUS Corp (Congresso UFLA 2026)** num ficheiro `.md` perfeitamente estruturado. 

O documento final preserva integralmente:
* A estrutura de ficheiros e categorias de páginas do repositório.
* O **Design System** completo (variáveis CSS de cores, tipografia, espaçamentos e bordas).
* Os blocos de código com a anatomia e esqueleto estrutural das páginas públicas, de autenticação e dos dashboards SPA.
* A biblioteca de componentes reutilizáveis (botões, elementos de formulário, cartões, alertas e tabelas).
* A lógica JavaScript e padrões de estado local (`localStorage`), validação e animações.
* As regras de nomenclatura CSS (BEM simplificado) e a lista de verificação (*checklist*) final antes do merge.

```
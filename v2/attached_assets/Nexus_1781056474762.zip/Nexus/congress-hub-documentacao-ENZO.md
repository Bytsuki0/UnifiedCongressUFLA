# Documentação Técnica — congress-hub

**Repositório:** [github.com/enzoavalentim/congress-hub](https://github.com/enzoavalentim/congress-hub)  
**Versão documentada:** branch `main` (55 commits)  
**Stack:** React 18 + TypeScript + Vite + Supabase (PostgreSQL) + TailwindCSS + shadcn/ui

---

## 1. Visão Geral do Sistema

O **congress-hub** é um sistema web de gerenciamento de avaliações para congressos acadêmicos. Ele permite cadastrar avaliadores, submeter trabalhos acadêmicos, categorizá-los e distribuir os trabalhos entre os avaliadores — tanto de forma manual quanto automática.

O sistema foi gerado com a plataforma **Lovable** (gerador low-code baseado em IA) e integra o **Supabase** como backend-as-a-service.

### Funcionalidades principais

| Módulo | Descrição |
|---|---|
| **Avaliadores** | CRUD completo — cadastro, edição e exclusão de avaliadores com nome, e-mail e instituição |
| **Trabalhos** | Submissão e gestão de trabalhos acadêmicos com título, autores, resumo, categoria e data |
| **Categorias** | Listagem somente-leitura das categorias do congresso com contagem de trabalhos |
| **Atribuições** | Distribuição de trabalhos a avaliadores, manual ou automática, com controle de status |

---

## 2. Arquitetura e Stack Técnica

```
congress-hub/
├── public/                    # Assets estáticos
├── src/
│   ├── components/
│   │   ├── Layout.tsx         # Shell da aplicação (header + nav)
│   │   └── ui/                # Componentes shadcn/ui (Radix UI)
│   ├── integrations/
│   │   └── supabase/
│   │       ├── client.ts      # Inicialização do cliente Supabase
│   │       └── types.ts       # Tipos TypeScript gerados do schema do banco
│   ├── lib/
│   │   └── types.ts           # Tipos de domínio da aplicação
│   ├── pages/
│   │   ├── Index.tsx          # Página inicial (dashboard)
│   │   ├── Avaliadores.tsx    # Listagem de avaliadores
│   │   ├── AvaliadorForm.tsx  # Formulário de avaliador (criar/editar)
│   │   ├── Trabalhos.tsx      # Listagem de trabalhos
│   │   ├── TrabalhoForm.tsx   # Formulário de trabalho (criar/editar)
│   │   ├── TrabalhoDetalhe.tsx# Visualização detalhada de trabalho
│   │   ├── Categorias.tsx     # Listagem de categorias (read-only)
│   │   ├── Atribuicoes.tsx    # Gestão de atribuições
│   │   └── NotFound.tsx       # Página 404
│   ├── services/
│   │   └── avaliacaoService.ts# Lógica de negócio das atribuições
│   └── App.tsx                # Configuração de rotas
├── supabase/
│   └── config.toml            # Configuração do projeto Supabase
├── .env                       # Variáveis de ambiente (URL e chave pública)
└── package.json
```

### Dependências principais

| Pacote | Finalidade |
|---|---|
| `@supabase/supabase-js` v2.105 | Cliente para comunicação com o banco |
| `@tanstack/react-query` v5 | Cache e gerenciamento de estado assíncrono |
| `react-router-dom` v6 | Roteamento SPA |
| `zod` v3 | Validação de formulários (schema-first) |
| `react-hook-form` v7 | Gerenciamento de formulários |
| `sonner` | Notificações toast |
| `@radix-ui/*` | Primitivos acessíveis de UI (via shadcn) |
| `tailwindcss` v3 | Estilização utilitária |
| `vite` v5 | Bundler e dev server |

---

## 3. Banco de Dados

### 3.1 Plataforma e Configuração

O banco de dados é um **PostgreSQL hospedado no Supabase** (versão PostgREST `14.5`).

```
Project ID : enorwxaolpbypbikklpy
URL        : https://enorwxaolpbypbikklpy.supabase.co
```

A conexão é feita exclusivamente via **chave anônima pública** (JWT `anon`), o que significa que toda a segurança de acesso é gerenciada pelas políticas de **Row Level Security (RLS)** do PostgreSQL, habilitadas pelo Supabase.

```typescript
// src/integrations/supabase/client.ts
import { createClient } from '@supabase/supabase-js';
import type { Database } from './types';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_PUBLISHABLE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);
```

---

### 3.2 Schema Completo do Banco

O banco possui **6 tabelas** no schema `public`, **2 enums** e **4 funções PostgreSQL**.

#### Diagrama Entidade-Relacionamento

```
┌─────────────┐       ┌──────────────────────────────┐       ┌─────────────┐
│  categorias │       │          trabalhos            │       │ avaliadores │
│─────────────│       │──────────────────────────────│       │─────────────│
│ id (PK)     │◄──────│ id (PK)                      │       │ id (PK)     │
│ nome        │       │ titulo                       │       │ nome        │
│ created_at  │       │ autores                      │       │ email       │
└─────────────┘       │ resumo                       │       │ instituicao │
                      │ categoria_id (FK)            │       │ user_id     │
                      │ data_submissao               │       │ created_at  │
                      │ aluno_id                     │       └─────────────┘
                      │ created_at                   │              │
                      └──────────────────────────────┘              │
                                      │                             │
                                      ▼                             ▼
                             ┌──────────────────────────────────────┐
                             │             avaliacoes               │
                             │──────────────────────────────────────│
                             │ id (PK)                              │
                             │ trabalho_id (FK → trabalhos)         │
                             │ avaliador_id (FK → avaliadores)      │
                             │ status (ENUM: avaliacao_status)      │
                             │ data_atribuicao                      │
                             │ created_at                           │
                             └──────────────────────────────────────┘

┌──────────────┐      ┌────────────────────────────────┐
│   profiles   │      │          user_roles            │
│──────────────│      │────────────────────────────────│
│ id (PK)      │      │ id (PK)                        │
│ nome         │      │ user_id                        │
│ email        │      │ role (ENUM: app_role)          │
│ created_at   │      │ created_at                     │
└──────────────┘      └────────────────────────────────┘
```

---

### 3.3 Descrição Detalhada das Tabelas

#### Tabela: `avaliadores`

Armazena os avaliadores cadastrados no congresso.

| Coluna | Tipo | Nulável | Default | Descrição |
|---|---|---|---|---|
| `id` | `uuid` | NOT NULL | `gen_random_uuid()` | PK — identificador único |
| `nome` | `text` | NOT NULL | — | Nome completo do avaliador |
| `email` | `text` | NOT NULL | — | E-mail (único por constraint) |
| `instituicao` | `text` | NOT NULL | — | Instituição de origem |
| `user_id` | `uuid` | NULL | — | FK opcional para auth.users (Supabase Auth) |
| `created_at` | `timestamptz` | NOT NULL | `now()` | Timestamp de criação |

**Validações no formulário (Zod):**
- `nome`: mínimo 1 char, máximo 100
- `email`: formato de e-mail válido, máximo 255 chars
- `instituicao`: mínimo 1 char, máximo 150

**Constraint notável:** duplicidade de `email` é rejeitada com código PostgreSQL `23505` (unique violation), tratado explicitamente no frontend.

---

#### Tabela: `trabalhos`

Armazena os trabalhos acadêmicos submetidos ao congresso.

| Coluna | Tipo | Nulável | Default | Descrição |
|---|---|---|---|---|
| `id` | `uuid` | NOT NULL | `gen_random_uuid()` | PK |
| `titulo` | `text` | NOT NULL | — | Título do trabalho |
| `autores` | `text` | NOT NULL | — | Lista de autores (string livre, ex: "João, Maria") |
| `resumo` | `text` | NOT NULL | — | Texto do resumo |
| `categoria_id` | `uuid` | NOT NULL | — | FK → `categorias.id` |
| `data_submissao` | `date` | NOT NULL | `now()` | Data de submissão |
| `aluno_id` | `uuid` | NULL | — | FK opcional para auth.users (autor aluno) |
| `created_at` | `timestamptz` | NOT NULL | `now()` | Timestamp de criação |

**Validações no formulário (Zod):**
- `titulo`: mínimo 1 char, máximo 200
- `autores`: mínimo 1 char, máximo 300
- `resumo`: mínimo 10 chars, máximo 5.000
- `categoria_id`: UUID válido (obrigatório)
- `data_submissao`: campo obrigatório

**Foreign keys:**
- `trabalhos.categoria_id` → `categorias.id` (nomeada `trabalhos_categoria_id_fkey`)

---

#### Tabela: `categorias`

Categorias fixas do congresso para organizar os trabalhos. A página de Categorias no frontend é **somente-leitura** — não há formulário de criação.

| Coluna | Tipo | Nulável | Default | Descrição |
|---|---|---|---|---|
| `id` | `uuid` | NOT NULL | `gen_random_uuid()` | PK |
| `nome` | `text` | NOT NULL | — | Nome da categoria |
| `created_at` | `timestamptz` | NOT NULL | `now()` | Timestamp de criação |

---

#### Tabela: `avaliacoes`

Tabela de junção entre `avaliadores` e `trabalhos`. Representa a atribuição de um trabalho a um avaliador e rastreia o status da avaliação.

| Coluna | Tipo | Nulável | Default | Descrição |
|---|---|---|---|---|
| `id` | `uuid` | NOT NULL | `gen_random_uuid()` | PK |
| `avaliador_id` | `uuid` | NOT NULL | — | FK → `avaliadores.id` |
| `trabalho_id` | `uuid` | NOT NULL | — | FK → `trabalhos.id` |
| `status` | `avaliacao_status` | NOT NULL | `'pendente'` | Status atual da avaliação |
| `data_atribuicao` | `timestamptz` | NOT NULL | `now()` | Quando foi atribuído |
| `created_at` | `timestamptz` | NOT NULL | `now()` | Timestamp de criação |

**Foreign keys:**
- `avaliacoes.avaliador_id` → `avaliadores.id` (nomeada `avaliacoes_avaliador_id_fkey`)
- `avaliacoes.trabalho_id` → `trabalhos.id` (nomeada `avaliacoes_trabalho_id_fkey`)

**Constraint de unicidade implícita:** a combinação `(avaliador_id, trabalho_id)` é tratada como única — violações são capturadas pelo código `23505` no `avaliacaoService.ts`.

---

#### Tabela: `profiles`

Perfis de usuários autenticados (espelha informações do `auth.users` do Supabase).

| Coluna | Tipo | Nulável | Default | Descrição |
|---|---|---|---|---|
| `id` | `uuid` | NOT NULL | — | PK (mesmo ID do `auth.users`) |
| `nome` | `text` | NOT NULL | — | Nome do usuário |
| `email` | `text` | NOT NULL | — | E-mail do usuário |
| `created_at` | `timestamptz` | NOT NULL | `now()` | Timestamp de criação |

> **Nota:** A tabela `profiles` existe no schema mas **nenhuma página do frontend a utiliza diretamente**. Ela serve de suporte para o sistema de autenticação e RBAC.

---

#### Tabela: `user_roles`

Controle de papéis (RBAC) dos usuários autenticados.

| Coluna | Tipo | Nulável | Default | Descrição |
|---|---|---|---|---|
| `id` | `uuid` | NOT NULL | `gen_random_uuid()` | PK |
| `user_id` | `uuid` | NOT NULL | — | FK → `auth.users.id` |
| `role` | `app_role` | NOT NULL | — | Papel: `aluno`, `avaliador` ou `gestor` |
| `created_at` | `timestamptz` | NOT NULL | `now()` | Timestamp de criação |

---

### 3.4 Enums do Banco de Dados

#### `app_role`

Define os papéis possíveis de um usuário no sistema.

```sql
CREATE TYPE app_role AS ENUM ('aluno', 'avaliador', 'gestor');
```

| Valor | Descrição |
|---|---|
| `aluno` | Estudante que submeteu trabalhos |
| `avaliador` | Avaliador do congresso |
| `gestor` | Administrador do sistema |

#### `avaliacao_status`

Define o ciclo de vida de uma avaliação.

```sql
CREATE TYPE avaliacao_status AS ENUM ('pendente', 'em_avaliacao', 'concluida');
```

| Valor | Label no frontend | Descrição |
|---|---|---|
| `pendente` | "Pendente" | Trabalho atribuído, avaliação não iniciada |
| `em_avaliacao` | "Em avaliação" | Avaliação em andamento |
| `concluida` | "Concluída" | Avaliação finalizada |

---

### 3.5 Funções PostgreSQL (RLS Helpers)

O banco define **4 funções** no schema `public`, usadas principalmente para implementar políticas de Row Level Security de forma reutilizável:

#### `has_role(_role app_role, _user_id uuid) → boolean`

Verifica se um usuário possui um papel específico.

```sql
SELECT has_role('gestor', auth.uid());
```

#### `is_aluno_dono_trabalho(_trabalho_id uuid, _user_id uuid) → boolean`

Verifica se o usuário autenticado é o aluno que submeteu determinado trabalho.

```sql
SELECT is_aluno_dono_trabalho('uuid-do-trabalho', auth.uid());
```

#### `is_avaliador_de_trabalho(_trabalho_id uuid, _user_id uuid) → boolean`

Verifica se o usuário está associado como avaliador de um trabalho específico.

```sql
SELECT is_avaliador_de_trabalho('uuid-do-trabalho', auth.uid());
```

#### `is_avaliador_user(_avaliador_id uuid, _user_id uuid) → boolean`

Verifica se um registro de avaliador pertence ao usuário autenticado (pela coluna `avaliadores.user_id`).

```sql
SELECT is_avaliador_user('uuid-do-avaliador', auth.uid());
```

---

### 3.6 Row Level Security (RLS)

O Supabase habilita RLS por padrão. As funções acima são os building blocks para políticas como:

- **Gestores** (via `has_role('gestor', ...)`) têm acesso total a todas as tabelas
- **Avaliadores** podem ver apenas seus próprios trabalhos atribuídos (via `is_avaliador_de_trabalho`)
- **Alunos** podem editar apenas seus próprios trabalhos (via `is_aluno_dono_trabalho`)

> O código das políticas RLS não está commitado no repositório (são gerenciadas diretamente no dashboard Supabase), mas as funções helper indicam claramente o modelo de segurança pretendido.

---

## 4. Camada de Serviço — `avaliacaoService.ts`

A lógica de negócio mais complexa do sistema está encapsulada em `src/services/avaliacaoService.ts`. Este arquivo centraliza todas as regras de atribuição de trabalhos.

### Constante de limite

```typescript
// src/lib/types.ts
export const LIMITE_TRABALHOS_POR_AVALIADOR = 5;
```

Cada avaliador pode receber no máximo **5 trabalhos**. Este limite é verificado tanto no cliente quanto na query de contagem antes do INSERT.

### Funções exportadas

#### `listarAvaliacoes(): Promise<Avaliacao[]>`
Busca todas as avaliações ordenadas por `data_atribuicao` descendente.

#### `listarTrabalhosDoAvaliador(avaliadorId): Promise<Avaliacao[]>`
Busca todas as avaliações de um avaliador específico.

#### `listarAvaliadoresDoTrabalho(trabalhoId): Promise<Avaliacao[]>`
Busca todos os avaliadores atribuídos a um trabalho específico.

#### `contarCargaPorAvaliador(): Promise<Record<string, number>>`
Retorna um mapa `{ avaliadorId: quantidade }` com a carga atual de cada avaliador.

#### `atribuirTrabalho(avaliadorId, trabalhoId): Promise<Avaliacao>`

Atribuição manual com duas validações:
1. **Verificação de limite:** consulta `COUNT(*)` na tabela `avaliacoes` onde `avaliador_id = avaliadorId`. Se `>= LIMITE_TRABALHOS_POR_AVALIADOR`, lança erro.
2. **Unicidade:** o INSERT retorna código `23505` se o par `(avaliador, trabalho)` já existir — lança erro com mensagem específica.

```typescript
// Exemplo de tratamento de erro de constraint
if (error.code === "23505") {
  throw new Error("Este trabalho já foi atribuído a este avaliador.");
}
```

#### `removerAvaliacao(id): Promise<void>`
Remove uma atribuição pelo ID.

#### `atualizarStatus(id, status): Promise<void>`
Atualiza o campo `status` de uma avaliação para um dos valores do enum `avaliacao_status`.

#### `distribuirAutomaticamente(avaliadores, trabalhos): Promise<number>`

Algoritmo de distribuição automática:

```
1. Busca todas as avaliações existentes
2. Constrói mapa de carga por avaliador
3. Constrói conjunto de pares (avaliador:trabalho) já existentes
4. Filtra trabalhos que ainda não têm nenhum avaliador atribuído
5. Para cada trabalho pendente:
   a. Filtra avaliadores com carga < LIMITE e que ainda não avaliam este trabalho
   b. Ordena pelo menor número de trabalhos atuais (balanceamento de carga)
   c. Atribui ao primeiro candidato disponível
   d. Atualiza o mapa de carga local (sem nova query)
6. Retorna o número de atribuições criadas
```

**Propriedades do algoritmo:**
- Balanceamento de carga (menor carga primeiro)
- Evita duplicatas
- Respeita o limite por avaliador
- Atribui apenas trabalhos sem nenhum avaliador (não redistribui)
- Retorna `0` se não houver trabalhos disponíveis

---

## 5. Roteamento e Páginas

Definido em `src/App.tsx` com `react-router-dom` v6. Todas as rotas ficam dentro do componente `<Layout>` que provê o header e a navbar.

| Rota | Componente | Operações no Banco |
|---|---|---|
| `/` | `Index` | Nenhuma |
| `/avaliadores` | `Avaliadores` | `SELECT * FROM avaliadores ORDER BY created_at DESC` |
| `/avaliadores/novo` | `AvaliadorForm` | `INSERT INTO avaliadores` |
| `/avaliadores/:id/editar` | `AvaliadorForm` | `SELECT` + `UPDATE avaliadores WHERE id = :id` |
| `/trabalhos` | `Trabalhos` | `SELECT * FROM trabalhos` + `SELECT * FROM categorias` |
| `/trabalhos/novo` | `TrabalhoForm` | `SELECT * FROM categorias` + `INSERT INTO trabalhos` |
| `/trabalhos/:id` | `TrabalhoDetalhe` | `SELECT * FROM trabalhos WHERE id = :id` + `SELECT categorias` |
| `/trabalhos/:id/editar` | `TrabalhoForm` | `SELECT` + `UPDATE trabalhos WHERE id = :id` |
| `/categorias` | `Categorias` | `SELECT * FROM categorias` + `SELECT * FROM trabalhos` |
| `/atribuicoes` | `Atribuicoes` | Múltiplas — ver `avaliacaoService.ts` |

---

## 6. Padrões de Acesso ao Banco

### Padrão direto (pages)

As páginas simples fazem queries diretamente via cliente Supabase com o hook `useEffect`:

```typescript
// Exemplo de Avaliadores.tsx
const { data, error } = await supabase
  .from("avaliadores")
  .select("*")
  .order("created_at", { ascending: false });
```

### Padrão via serviço (Atribuições)

A página `Atribuicoes.tsx` delega toda a lógica ao `avaliacaoService.ts`, que é o único lugar com regras de negócio complexas:

```typescript
// Atribuicoes.tsx
import { atribuirTrabalho, distribuirAutomaticamente, listarAvaliacoes } from "@/services/avaliacaoService";
```

### Padrão de validação

Formulários usam `zod` para validação client-side antes de qualquer chamada ao banco:

```typescript
const parsed = avaliadorSchema.safeParse(form);
if (!parsed.success) { /* exibe erros */ return; }
// só então faz a query
await supabase.from("avaliadores").insert(payload);
```

---

## 7. Configuração de Ambiente

### Variáveis de ambiente (`.env`)

```env
VITE_SUPABASE_PROJECT_ID="enorwxaolpbypbikklpy"
VITE_SUPABASE_URL="https://enorwxaolpbypbikklpy.supabase.co"
VITE_SUPABASE_PUBLISHABLE_KEY="eyJhbGci..."  # JWT anon key
```

> ⚠️ **Atenção de segurança:** O arquivo `.env` com a chave pública está commitado no repositório. Isso é aceitável para a `anon key` do Supabase (que é destinada ao uso no frontend), **desde que** as políticas RLS estejam corretamente configuradas no banco para proteger os dados.

### Supabase CLI (`supabase/config.toml`)

```toml
project_id = "enorwxaolpbypbikklpy"
```

---

## 8. Como Rodar Localmente

```bash
# 1. Clonar o repositório
git clone https://github.com/enzoavalentim/congress-hub.git
cd congress-hub

# 2. Instalar dependências (projeto usa bun.lockb, mas npm também funciona)
npm install
# ou
bun install

# 3. Configurar variáveis de ambiente
# O .env já está commitado com as credenciais do projeto Supabase hospedado

# 4. Rodar em modo desenvolvimento
npm run dev

# 5. Build de produção
npm run build

# 6. Executar testes
npm run test
```

---

## 9. Observações Técnicas e Pontos de Atenção

### Autenticação não implementada no frontend
Embora o banco tenha as tabelas `profiles`, `user_roles` e as funções RLS (`has_role`, `is_aluno_dono_trabalho`, etc.), o frontend **não possui nenhuma tela de login**. Não há rotas protegidas, provider de autenticação, ou uso de `supabase.auth`. O sistema opera inteiramente com a `anon key` em modo público.

### Categorias são fixas
A tabela `categorias` não possui formulário de criação no frontend. As categorias são gerenciadas diretamente pelo banco (via Supabase Studio ou migrations). A página `/categorias` é somente-leitura.

### Limite de avaliadores por trabalho
Não há limite configurado para o número de avaliadores por trabalho (o limite de 5 é apenas por avaliador). Um trabalho pode ter N avaliadores.

### Sem paginação
As queries de listagem (`avaliadores`, `trabalhos`, `avaliacoes`) buscam todos os registros sem paginação. Para volumes grandes, isso pode representar um gargalo.

### Estado local sem cache global
A aplicação usa `useState` + `useEffect` para gerenciar estado nas páginas. Apesar de `@tanstack/react-query` estar instalado e configurado no `App.tsx`, ele não é usado nas queries atuais — as páginas fazem fetch manual. Isso significa que não há invalidação de cache automática entre navegações.

### `aluno_id` em `trabalhos` e `user_id` em `avaliadores`
Ambos são `uuid | null` opcionais que existem para suportar um futuro sistema de autenticação onde os usuários logados possam gerenciar seus próprios dados. Atualmente não são populados pelo frontend.

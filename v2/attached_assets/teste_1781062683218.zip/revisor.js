/* ============================================
   NEXUS — Revisor (Reviewer Panel) · JS
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {

  // Safe localStorage helper
  function getLocalStorageItem(key, defaultValue) {
    try {
      const val = localStorage.getItem(key);
      return val ? JSON.parse(val) : defaultValue;
    } catch (e) {
      console.error(`Error parsing localStorage key "${key}":`, e);
      return defaultValue;
    }
  }

  // Premium Toast Notification helper
  function showToast(message, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let iconSvg = '';
    if (type === 'success') {
      iconSvg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
          <polyline points="22 4 12 14.01 9 11.01"></polyline>
        </svg>
      `;
    } else if (type === 'danger') {
      iconSvg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="12" y1="8" x2="12" y2="12"></line>
          <line x1="12" y1="16" x2="12.01" y2="16"></line>
        </svg>
      `;
    } else if (type === 'warning') {
      iconSvg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
          <line x1="12" y1="9" x2="12" y2="13"></line>
          <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
      `;
    } else {
      iconSvg = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="12" y1="16" x2="12" y2="12"></line>
          <line x1="12" y1="8" x2="12.01" y2="8"></line>
        </svg>
      `;
    }

    toast.innerHTML = `
      ${iconSvg}
      <span style="font-family: var(--font-family-title);">${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('hide');
      toast.addEventListener('animationend', () => {
        toast.remove();
      });
    }, 4000);
  }

  // Load dynamic user info from localStorage
  const loggedName = localStorage.getItem('nexus_user_name');
  const loggedMatricula = localStorage.getItem('nexus_user_matricula');
  
  if (loggedName) {
    const userNameEl = document.querySelector('.user-info .user-name');
    const userAvatarEl = document.querySelector('.user-info .user-avatar');
    if (userNameEl) userNameEl.textContent = loggedName;
    if (userAvatarEl) {
      const parts = loggedName.trim().split(/\s+/);
      const initials = parts.length >= 2 ? (parts[0][0] + parts[parts.length - 1][0]).toUpperCase() : parts[0][0].toUpperCase();
      userAvatarEl.textContent = initials;
    }
  }
  if (loggedMatricula) {
    const userMetaEl = document.querySelector('.user-info .user-meta');
    if (userMetaEl) userMetaEl.textContent = `Reg: ${loggedMatricula} · DCC · UFLA`;
  }

  /* ---- Sidebar Navigation ---- */
  const navItems = document.querySelectorAll('.sidebar-nav .nav-item[data-section]');
  const sections = document.querySelectorAll('.section');

  function showSection(sectionId) {
    sections.forEach(s => s.classList.remove('active'));
    navItems.forEach(n => n.classList.remove('active'));

    const target = document.getElementById(sectionId);
    if (target) target.classList.add('active');

    const navItem = document.querySelector(`.nav-item[data-section="${sectionId}"]`);
    if (navItem) navItem.classList.add('active');
  }

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const sectionId = item.getAttribute('data-section');
      showSection(sectionId);
    });
  });

  // Keep track of the active sub ID on evaluation screen
  let activeSubId = null;

  /* ---- Work Card Click / Render ---- */
  renderAssignments();

  // Run status simulator and render assignments
  runStatusSimulation();
  renderAssignments();

  // Polling simulator
  setInterval(() => {
    runStatusSimulation();
    const beforeStr = localStorage.getItem('nexus_submissoes') || '[]';
    const isEvalScreenActive = document.getElementById('avaliacao').classList.contains('active');
    
    // Check if another tab modified the state
    renderAssignments();
    
    if (isEvalScreenActive && activeSubId) {
      // Re-populate if updated (e.g., admin revert)
      const currentSubs = getLocalStorageItem('nexus_submissoes', []);
      const sub = currentSubs.find(s => s.id === activeSubId);
      if (sub && sub.status !== 'Em Avaliação') {
        openEvaluation(activeSubId); // Reload screen to lock it
      }
    }
  }, 4000);

  /* ---- Back to Atribuições ---- */
  const backBtn = document.getElementById('backToAtribuicoes');
  if (backBtn) {
    backBtn.addEventListener('click', () => {
      showSection('atribuicoes');
      activeSubId = null;
      renderAssignments();
    });
  }

  /* ---- Tab Switching (Avaliação) ---- */
  const tabBtns = document.querySelectorAll('.tab-btn[data-tab]');
  const tabContents = document.querySelectorAll('.tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const tabId = btn.getAttribute('data-tab');

      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const target = document.getElementById(tabId);
      if (target) target.classList.add('active');
    });
  });

  /* ---- Character Counter ---- */
  const textarea = document.getElementById('parecerTexto');
  const charCounter = document.getElementById('charCounter');

  function updateCharCounter() {
    if (!textarea || !charCounter) return;
    const config = getLocalStorageItem('nexus_config', { minChars: 1000 });
    const minChars = config.minChars;
    const len = textarea.value.length;
    charCounter.textContent = `${len} / ${minChars} min.`;

    const select = document.getElementById('resultadoFinal');
    const needsMin = select && (select.value === 'Correções Necessárias' || select.value === 'Aprovado com Correções');
    if (needsMin) {
      if (len >= minChars) {
        charCounter.style.color = 'var(--green-700)';
      } else {
        charCounter.style.color = 'var(--color-danger)';
      }
    } else {
      charCounter.style.color = '';
    }
  }

  if (textarea && charCounter) {
    textarea.addEventListener('input', updateCharCounter);
    
    // Listen for resultadoFinal changes to update color feedback dynamically
    const select = document.getElementById('resultadoFinal');
    if (select) {
      select.addEventListener('change', updateCharCounter);
    }
  }

  window.addEventListener('storage', (e) => {
    if (e.key === 'nexus_config') {
      updateCharCounter();
      applyRevisorLinks();
      renderRevisorPanel(); // Also refresh the main panel to instantly apply alert hours changes
    }
  });

  function applyRevisorLinks() {
    const config = getLocalStorageItem('nexus_config', {});
    if (!config.links) return;

    const bindLink = (id, url) => {
      const btn = document.getElementById(id);
      if (btn) {
        if (url) {
          btn.onclick = (e) => {
            e.preventDefault();
            window.open(url, '_blank');
          };
          btn.style.opacity = '1';
          btn.style.pointerEvents = 'auto';
        } else {
          btn.onclick = (e) => {
            e.preventDefault();
            alert('Link não configurado no painel administrativo.');
          };
          btn.style.opacity = '0.5';
        }
      }
    };

    bindLink('btn-form-pesquisa', config.links.formPesquisa);
    bindLink('btn-form-extensao', config.links.formExtensao);
    bindLink('btn-form-ensino', config.links.formEnsino);
    
    bindLink('btn-arq-edital', config.links.arqEdital);
    bindLink('btn-arq-manual', config.links.arqManual);
    bindLink('btn-arq-diretrizes', config.links.arqDiretrizes);
    bindLink('btn-arq-etica', config.links.arqEtica);
    bindLink('btn-arq-modelo', config.links.arqModelo);
  }

  // Apply links on initial load
  applyRevisorLinks();

  /* ---- Form Select interaction ---- */
  const resultadoSelect = document.getElementById('resultadoFinal');
  if (resultadoSelect) {
    resultadoSelect.addEventListener('change', () => {
      if (resultadoSelect.value) {
        resultadoSelect.style.borderColor = 'var(--color-primary)';
      }
      // Re-trigger counter validation styling
      if (textarea) textarea.dispatchEvent(new Event('input'));
    });
  }

  /* ---- Save Draft Button ---- */
  const saveDraftBtn = document.getElementById('btnSalvarRascunho');
  if (saveDraftBtn) {
    saveDraftBtn.addEventListener('click', () => {
      if (!activeSubId) return;

      const select = document.getElementById('resultadoFinal');
      const text = document.getElementById('parecerTexto');
      const ratingSelects = document.querySelectorAll('.criteria-rating');

      const ratings = {};
      ratingSelects.forEach(sel => {
        ratings[sel.id] = sel.value;
      });

      const draft = {
        resultado: select ? select.value : '',
        comentarios: text ? text.value : '',
        ratings: ratings
      };

      const drafts = getLocalStorageItem('nexus_revisor_drafts', {});
      drafts[activeSubId] = draft;
      localStorage.setItem('nexus_revisor_drafts', JSON.stringify(drafts));

      showToast('Rascunho de avaliação salvo com sucesso!', 'success');

      saveDraftBtn.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        RASCUNHO SALVO
      `;
      saveDraftBtn.disabled = true;
      setTimeout(() => {
        saveDraftBtn.innerHTML = `
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
          SALVAR RASCUNHO
        `;
        saveDraftBtn.disabled = false;
      }, 1500);
    });
  }

  /* ---- Submit Parecer Button ---- */
  const submitBtn = document.getElementById('btnEnviarParecer');
  if (submitBtn) {
    submitBtn.addEventListener('click', () => {
      if (!activeSubId) return;

      const select = document.getElementById('resultadoFinal');
      const text = document.getElementById('parecerTexto');
      const ratingSelects = document.querySelectorAll('.criteria-rating');
      
      let valid = true;

      // 1. Validate result
      if (select && !select.value) {
        select.style.borderColor = 'var(--color-danger)';
        valid = false;
      } else if (select) {
        select.style.borderColor = '';
      }

      // 2. Validate comments
      if (text) {
        const config = getLocalStorageItem('nexus_config', { minChars: 1000 });
        const minChars = config.minChars;
        const needsMin = select && (select.value === 'Correções Necessárias' || select.value === 'Aprovado com Correções');
        if (needsMin && text.value.length < minChars) {
          text.style.borderColor = 'var(--color-danger)';
          showToast(`Comentário detalhado deve conter no mínimo ${minChars} caracteres.`, 'danger');
          valid = false;
        } else if (!text.value.trim()) {
          text.style.borderColor = 'var(--color-danger)';
          showToast('Os comentários e correções do revisor são obrigatórios.', 'danger');
          valid = false;
        } else {
          text.style.borderColor = '';
        }
      }

      // 3. Validate criteria ratings (RF33)
      ratingSelects.forEach(sel => {
        if (!sel.value) {
          sel.style.borderColor = 'var(--color-danger)';
          valid = false;
        } else {
          sel.style.borderColor = '';
        }
      });

      if (!valid) {
        return;
      }

      // Confirmation
        const submissoes = getLocalStorageItem('nexus_submissoes', []);
        const subIndex = submissoes.findIndex(s => s.id === activeSubId);
        if (subIndex === -1) return;

        const sub = submissoes[subIndex];
        const latestRound = sub.rodadas && sub.rodadas.length > 0 ? sub.rodadas[sub.rodadas.length - 1] : { pdfName: '', parecer: '', comentarios: '' };

        // Save rating values
        const ratings = {};
        ratingSelects.forEach(sel => {
          ratings[sel.id] = sel.value;
        });

        // Update latest round
        latestRound.parecer = select.value;
        latestRound.comentarios = text.value;
        latestRound.status = select.value;
        latestRound.dataAvaliacao = new Date().toISOString();
        latestRound.ratings = ratings;

        const previousStatus = sub.status;
        const newStatus = select.value;

        sub.status = newStatus;
        sub.ultimaAtualizacao = new Date().toISOString();

        // Status history entry (RF19)
        sub.statusHistory = sub.statusHistory || [];
        sub.statusHistory.push({
          statusAnterior: previousStatus,
          statusNovo: newStatus,
          dataHora: new Date().toISOString(),
          justificativa: `Avaliação registrada pelo revisor Prof. Almeida.`
        });

        submissoes[subIndex] = sub;
        localStorage.setItem('nexus_submissoes', JSON.stringify(submissoes));

        // Clear draft
        const drafts = getLocalStorageItem('nexus_revisor_drafts', {});
        delete drafts[activeSubId];
        localStorage.setItem('nexus_revisor_drafts', JSON.stringify(drafts));

        // Create notification
        const notificacoes = getLocalStorageItem('nexus_notificacoes', []);
        notificacoes.unshift({
          tipo: 'PARECER',
          title: 'Parecer técnico emitido',
          desc: `O revisor Prof. Almeida emitiu o parecer "${newStatus}" para o trabalho "${sub.titulo}". Protocolo: ${sub.id}`,
          time: 'agora',
          unread: true,
          timestamp: new Date().toISOString()
        });
        localStorage.setItem('nexus_notificacoes', JSON.stringify(notificacoes));

        showToast('Parecer definitivo enviado com sucesso!', 'success');
        
        // Return to assignments and render
        showSection('atribuicoes');
        activeSubId = null;
        renderAssignments();
    });
  }

  // ---- Helper: Open Evaluation Screen ----
  function openEvaluation(subId) {
    activeSubId = subId;
    showSection('avaliacao');

    const submissoes = getLocalStorageItem('nexus_submissoes', []);
    const sub = submissoes.find(s => s.id === subId);
    if (!sub) return;

    // Sub-header details
    const dataRef = sub.ultimaAtualizacao || sub.dataSubmissao;
    const deadline = new Date(dataRef);
    deadline.setDate(deadline.getDate() + 7);
    const deadlineStr = deadline.toLocaleDateString('pt-BR');

    const subIdEl = document.querySelector('.avaliacao-subheader .sub-id');
    if (subIdEl) {
      subIdEl.textContent = `${sub.id} · ${sub.categoria.toUpperCase()} · Prazo: ${deadlineStr}`;
    }

    // Update Round Title
    const roundTitleEl = document.querySelector('.review-section-title');
    if (roundTitleEl) {
      const currentRoundNum = sub.rodadas && sub.rodadas.length > 0 ? sub.rodadas.length : 1;
      const roundStr = currentRoundNum.toString().padStart(2, '0');
      roundTitleEl.textContent = `Avaliação — Rodada ${roundStr}`;
    }

    // PDF filename and iframe loader
    const latestRound = sub.rodadas && sub.rodadas.length > 0 ? sub.rodadas[sub.rodadas.length - 1] : null;
    const pdfViewer = document.querySelector('.pdf-viewer');
    if (pdfViewer) {
      if (latestRound && latestRound.pdfData) {
        // Show actual uploaded PDF inside an iframe
        pdfViewer.style.position = 'relative';
        pdfViewer.innerHTML = `<iframe src="${latestRound.pdfData}" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none; z-index: 5;"></iframe>`;
      } else {
        // Show static loaded mock state (no eternal loading bar animation)
        pdfViewer.style.position = '';
        pdfViewer.innerHTML = `
          <svg class="pdf-viewer-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="width: 64px; height: 64px; color: var(--gray-400);"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
          <div class="pdf-viewer-filename">${latestRound ? latestRound.pdfName : 'TRABALHO.PDF'}</div>
          <div class="pdf-viewer-description">Visualizador de PDF embutido · 12 páginas (Mock)</div>
          <div class="pdf-progress-bar">
            <div class="pdf-progress-fill" style="width: 100%; animation: none;"></div>
          </div>
          <div style="font-size: var(--fs-xs); color: var(--green-700); font-weight: bold; margin-top: 4px;">CARREGADO COM SUCESSO (MOCK)</div>
        `;
      }
    }

    // Inject dynamic criteria (RF33)
    const criteriaContainer = document.getElementById('dynamic-criteria-container');
    if (criteriaContainer) {
      let criteriaSet = [];
      const cat = sub.categoria.toLowerCase();
      if (cat === 'pibic' || cat === 'bic-junior') {
        criteriaSet = [
          'Clareza e originalidade do tema',
          'Rigor metodológico aplicado',
          'Consistência dos resultados alcançados',
          'Aderência ao referencial teórico',
          'Qualidade geral da redação científica'
        ];
      } else if (cat === 'extensao') {
        criteriaSet = [
          'Impacto social e transformador mensurável',
          'Articulação ativa universidade-comunidade',
          'Pertinência territorial do projeto',
          'Indicadores claros de continuidade',
          'Participação efetiva dos beneficiários'
        ];
      } else {
        criteriaSet = [
          'Inovação didática e criatividade',
          'Alinhamento com o projeto pedagógico',
          'Avaliação e acompanhamento da aprendizagem',
          'Replicabilidade e escalabilidade da prática',
          'Engajamento e interesse discente gerado'
        ];
      }

      let criteriaHtml = `<div class="review-section-overline" style="margin-top: var(--space-4); margin-bottom: var(--space-2);">Critérios de Avaliação (Obrigatórios)</div>`;
      criteriaSet.forEach((crit, index) => {
        criteriaHtml += `
          <div class="form-group" style="margin-bottom: var(--space-3);">
            <label class="form-label" style="font-size: 11px; font-weight: var(--fw-semibold); color: var(--color-text-secondary); text-transform: none; letter-spacing: normal;" for="crit-${index}">${crit}</label>
            <select class="form-select criteria-rating" id="crit-${index}" required>
              <option value="">Nota (1 a 5)</option>
              <option value="1">1 - Insuficiente</option>
              <option value="2">2 - Regular</option>
              <option value="3">3 - Bom</option>
              <option value="4">4 - Muito Bom</option>
              <option value="5">5 - Excelente</option>
            </select>
          </div>
        `;
      });
      criteriaContainer.innerHTML = criteriaHtml;
    }

    // Tab resets
    const tabBtnEval = document.querySelector('.tab-btn[data-tab="tab-avaliacao"]');
    if (tabBtnEval) tabBtnEval.click();

    // Populate Rounds History Tab (RF40)
    const historyTab = document.getElementById('tab-historico');
    if (historyTab) {
      historyTab.innerHTML = '';
      if (sub.rodadas.length <= 1 && (!latestRound || latestRound.parecer === '')) {
        historyTab.innerHTML = `
          <div class="empty-state" style="border: none; padding: var(--space-6) var(--space-4); margin: 0; background: transparent;">
            <div class="empty-state-icon" style="width: 48px; height: 48px; margin-bottom: var(--space-3); background: var(--gray-100);">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="width: 24px; height: 24px;">
                <circle cx="12" cy="12" r="10"/>
                <polyline points="12 6 12 12 16 14"/>
              </svg>
            </div>
            <h4 class="empty-state-title" style="font-size: var(--fs-sm); margin-bottom: 4px;">Sem rodadas anteriores</h4>
            <p class="empty-state-description" style="font-size: var(--fs-xs); max-width: 280px; margin-bottom: 0; line-height: var(--lh-normal);">Este trabalho está em sua primeira rodada de avaliação. Pareceres passados aparecerão aqui quando novas versões forem submetidas.</p>
          </div>
        `;
      } else {
        let histHtml = '<div class="historico-content" style="padding: var(--space-4) 0;">';
        sub.rodadas.forEach(r => {
          const dateObj = new Date(r.dataEnvio);
          const dateStr = dateObj.toLocaleDateString('pt-BR');
          histHtml += `
            <div class="historico-round" style="border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: var(--space-4); margin-bottom: var(--space-4);">
              <div class="historico-round-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-2);">
                <div class="historico-round-title" style="font-weight: var(--fw-bold); font-size: var(--fs-sm);">Rodada ${r.rodada}</div>
                <div class="historico-round-date" style="font-size: var(--fs-xs); color: var(--color-text-secondary);">${dateStr}</div>
              </div>
              <div class="historico-round-body" style="font-size: var(--fs-xs); color: var(--color-text-secondary);">
                <div><strong>PDF:</strong> <a href="#" class="btn-baixar-doc" data-filename="${r.pdfName}">${r.pdfName}</a></div>
                ${r.parecer ? `
                  <div style="margin-top: 4px;"><strong>Resultado:</strong> ${r.parecer}</div>
                  <div style="margin-top: 4px; padding: 6px; background: var(--gray-50); border-radius: 4px;"><em>"${r.comentarios}"</em></div>
                ` : '<div style="margin-top: 4px; color: var(--amber-600);">Pendente de avaliação nesta rodada</div>'}
              </div>
            </div>
          `;
        });
        histHtml += '</div>';
        historyTab.innerHTML = histHtml;
        
        // Re-attach download listener for dynamically injected history links
        setupSimulatedDownloads();
      }
    }

    // Populate current evaluation or draft
    const select = document.getElementById('resultadoFinal');
    const text = document.getElementById('parecerTexto');
    const ratingSelects = document.querySelectorAll('.criteria-rating');

    const drafts = getLocalStorageItem('nexus_revisor_drafts', {});
    const draft = drafts[subId];

    const isAlreadyEvaluated = latestRound && latestRound.parecer !== '';

    if (isAlreadyEvaluated) {
      // Lock form (RF37)
      if (select) {
        select.value = latestRound.parecer;
        select.disabled = true;
      }
      if (text) {
        text.value = latestRound.comentarios;
        text.disabled = true;
      }
      if (ratingSelects) {
        ratingSelects.forEach((sel, idx) => {
          if (latestRound.ratings && latestRound.ratings[sel.id]) {
            sel.value = latestRound.ratings[sel.id];
          }
          sel.disabled = true;
        });
      }
      if (saveDraftBtn) saveDraftBtn.style.display = 'none';
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
          PARECER DEFINITIVO ENVIADO
        `;
      }
    } else {
      // Enable and clear / load draft
      if (saveDraftBtn) saveDraftBtn.style.display = 'inline-flex';
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = `
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
          ENVIAR PARECER DEFINITIVO
        `;
      }

      if (select) {
        select.value = draft ? draft.resultado : '';
        select.disabled = false;
        select.style.borderColor = '';
      }
      if (text) {
        text.value = draft ? draft.comentarios : '';
        text.disabled = false;
        text.style.borderColor = '';
      }
      ratingSelects.forEach(sel => {
        sel.value = (draft && draft.ratings && draft.ratings[sel.id]) ? draft.ratings[sel.id] : '';
        sel.disabled = false;
        sel.style.borderColor = '';
      });
    }

    if (text) text.dispatchEvent(new Event('input'));
  }

  // ---- Render Assignments Dashboard ----
  function renderAssignments() {
    const reviewerEmail = localStorage.getItem('nexus_user_email') || 'prof.almeida@ufla.br';
    const submissoes = getLocalStorageItem('nexus_submissoes', []);
    
    const myAssignments = submissoes.filter(sub => {
      return sub.status === 'Em Avaliação' && sub.revisorEmail === reviewerEmail;
    });

    const sorted = myAssignments.map(sub => {
      const dataRef = sub.ultimaAtualizacao || sub.dataSubmissao;
      const deadline = new Date(dataRef);
      deadline.setDate(deadline.getDate() + 7); // 7 days evaluation deadline
      
      const now = new Date();
      const diffTime = deadline - now;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      const hoursRemaining = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60)));
      
      const latestRound = sub.rodadas && sub.rodadas.length > 0 
        ? sub.rodadas[sub.rodadas.length - 1] 
        : { pdfName: '', parecer: '', comentarios: '' };
      const isEvaluated = latestRound && latestRound.parecer !== '';

      return {
        sub,
        deadline,
        diffDays,
        hoursRemaining,
        isEvaluated,
        latestRound
      };
    });

    sorted.sort((a, b) => a.deadline - b.deadline);

    let countAtrib = sorted.length;
    let countPend = sorted.filter(x => !x.isEvaluated).length;
    let countAval = sorted.filter(x => x.isEvaluated).length;
    
    const configHours = parseInt(localStorage.getItem('nexus_config_alert_hours') || '48');
    let countCritical = sorted.filter(x => !x.isEvaluated && x.hoursRemaining <= configHours).length;

    const statValues = document.querySelectorAll('.stats-grid .stat-value');
    if (statValues.length >= 4) {
      statValues[0].textContent = countAtrib;
      statValues[1].textContent = countPend;
      statValues[2].textContent = countAval;
      statValues[3].textContent = countCritical > 0 ? `${countCritical} (<= ${configHours}h)` : '0';
      
      if (countCritical > 0) {
        statValues[3].classList.add('red');
      } else {
        statValues[3].classList.remove('red');
      }
    }

    const emptyState = document.getElementById('revisor-empty-state');
    const workList = document.getElementById('revisor-work-list');

    if (countAtrib === 0) {
      if (emptyState) emptyState.style.display = 'flex';
      if (workList) workList.style.display = 'none';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';
    if (workList) workList.style.display = 'flex';

    if (workList) {
      workList.innerHTML = '';
      sorted.forEach(item => {
        const sub = item.sub;
        const card = document.createElement('div');
        
        const isUrgent = !item.isEvaluated && item.hoursRemaining <= configHours;
        card.className = `work-card ${isUrgent ? 'urgent' : ''}`;
        card.setAttribute('data-id', sub.id);

        const deadlineStr = item.deadline.toLocaleDateString('pt-BR');
        let remainingStr = '';
        if (item.diffDays < 0) {
          remainingStr = 'Atrasado';
        } else if (item.diffDays === 0) {
          remainingStr = `Hoje (${item.hoursRemaining}h rest.)`;
        } else {
          remainingStr = `${item.diffDays} dias restantes`;
        }

        let badgeHtml = '';
        if (item.isEvaluated) {
          let bClass = 'badge-solid-green';
          if (item.latestRound.parecer === 'Reprovado' || item.latestRound.parecer === 'Desclassificado') bClass = 'badge-solid-red';
          else if (item.latestRound.parecer === 'Aprovado com Correções' || item.latestRound.parecer === 'Correções Necessárias') bClass = 'badge-solid-blue';
          badgeHtml = `<span class="badge ${bClass}">${item.latestRound.parecer}</span>`;
        } else {
          badgeHtml = `<span class="badge badge-solid-amber">PENDENTE</span>`;
        }

        card.innerHTML = `
          <div class="work-card-left">
            <div class="work-card-meta">
              <span class="work-card-id">${sub.id}</span>
              <span class="badge badge-gray">${sub.categoria.toUpperCase()}</span>
              ${isUrgent ? '<span class="work-card-flag">⚠ URGENTE</span>' : ''}
            </div>
            <div class="work-card-title">${sub.titulo}</div>
          </div>
          <div class="work-card-right">
            <div class="work-card-deadline">
              <div class="deadline-date">Prazo: ${deadlineStr}</div>
              <div class="deadline-remaining ${isUrgent ? 'danger' : ''}">${remainingStr}</div>
            </div>
            ${badgeHtml}
          </div>
        `;

        card.addEventListener('click', () => {
          openEvaluation(sub.id);
        });
        workList.appendChild(card);
      });
    }
  }

  // ---- Simulator function to advance status in localStorage ----
  function runStatusSimulation() {
    const submissoes = getLocalStorageItem('nexus_submissoes', []);
    let changed = false;
    
    const now = new Date();
    submissoes.forEach(sub => {
      const timeRef = new Date(sub.ultimaAtualizacao || sub.dataSubmissao);
      const elapsedSeconds = (now - timeRef) / 1000;
      
      if (sub.status === 'Recebido' && elapsedSeconds >= 12) {
        sub.status = 'Em Análise';
        sub.ultimaAtualizacao = new Date().toISOString();
        sub.statusHistory = sub.statusHistory || [];
        sub.statusHistory.push({
          statusAnterior: 'Recebido',
          statusNovo: 'Em Análise',
          dataHora: new Date().toISOString(),
          justificativa: 'Trabalho recebido pela comissão e encaminhado para análise preliminar de formato.'
        });
        
        const notificacoes = getLocalStorageItem('nexus_notificacoes', []);
        notificacoes.unshift({
          tipo: 'PRAZO',
          title: 'Trabalho em análise',
          desc: `O trabalho "${sub.titulo}" (ID: ${sub.id}) passou para status "Em Análise".`,
          time: 'agora',
          unread: true,
          timestamp: new Date().toISOString()
        });
        localStorage.setItem('nexus_notificacoes', JSON.stringify(notificacoes));
        
        changed = true;
      } else if (sub.status === 'Em Análise' && elapsedSeconds >= 12) {
        sub.status = 'Em Avaliação';
        sub.ultimaAtualizacao = new Date().toISOString();
        
        // Conflict checking (RF13 / RF31)
        const advisorEmail = sub.orientador;
        const coauthorEmails = (sub.coautores || []).filter(c => c && c.email).map(c => c.email);
        const isConflicted = advisorEmail === 'prof.almeida@ufla.br' || coauthorEmails.includes('prof.almeida@ufla.br');
        
        if (isConflicted) {
          sub.revisorEmail = '';
          sub.revisorNome = '';
          sub.conflito = true;
          sub.conflitoRegra = 'Orientador ou coautor cadastrado como revisor';
          
          const notificacoes = getLocalStorageItem('nexus_notificacoes', []);
          notificacoes.unshift({
            tipo: 'CONFLITO',
            title: 'Conflito de interesse detectado',
            desc: `O revisor Prof. Almeida possui conflito de interesse com o trabalho ${sub.id} (orientação/coautoria).`,
            time: 'agora',
            unread: true,
            timestamp: new Date().toISOString()
          });
          localStorage.setItem('nexus_notificacoes', JSON.stringify(notificacoes));
        } else {
          sub.revisorEmail = 'prof.almeida@ufla.br';
          sub.revisorNome = 'Prof. Dr. R. Almeida';
        }
        
        sub.statusHistory = sub.statusHistory || [];
        sub.statusHistory.push({
          statusAnterior: 'Em Análise',
          statusNovo: 'Em Avaliação',
          dataHora: new Date().toISOString(),
          justificativa: isConflicted ? 'Conflito detectado. Bloqueio automático de revisor.' : 'Trabalho distribuído para revisão cega de parecer técnico.'
        });
        
        changed = true;
      }
    });
    
    if (changed) {
      localStorage.setItem('nexus_submissoes', JSON.stringify(submissoes));
    }
  }

  // ---- Logout Confirmation ----
  const logoutLink = document.querySelector('.sidebar-footer .nav-item');
  if (logoutLink) {
    logoutLink.addEventListener('click', (e) => {
      e.preventDefault();
      if (confirm('Deseja realmente sair do Painel do Revisor?')) {
        localStorage.removeItem('nexus_user_name');
        localStorage.removeItem('nexus_user_matricula');
        localStorage.removeItem('nexus_user_email');
        localStorage.removeItem('nexus_user_perfil');
        window.location.href = 'login.html';
      }
    });
  }

  /* ---- Simulated Downloads for Prototype ---- */
  function setupSimulatedDownloads() {
    const downloadBtns = document.querySelectorAll('.btn-baixar-doc');
    downloadBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        const filename = btn.getAttribute('data-filename') || 'documento.pdf';
        
        let content = `NEXUS — SISTEMA DE SUBMISSÕES CIENTÍFICAS DA UFLA (CONGRESSO 2026)\n\n`;
        content += `Documento: ${filename}\n`;
        content += `------------------------------------------------------------\n\n`;
        content += `Este é um modelo de documento ou formulário oficial do Congresso NEXUS 2026.\n`;
        content += `O arquivo oficial correspondente a "${filename}" estará disponível para download direto no sistema em breve.\n\n`;
        content += `Para fins de homologação e testes do protótipo frontend, este arquivo placeholder foi gerado dinamicamente através de um Blob no navegador.\n\n`;
        content += `Nexus Corp & UFLA — 2026`;
        
        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      });
    });
  }

  setupSimulatedDownloads();

});
